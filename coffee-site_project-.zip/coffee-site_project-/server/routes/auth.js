const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('../db');
const { currentUser } = require('./helpers');

const router = express.Router();

router.post('/register', (req, res) => {
  const { name, email, pass } = req.body;
  if (!name || !email || !pass) return res.status(400).json({ error: 'Заполните все поля' });

  const exists = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  if (exists) return res.status(409).json({ error: 'Такой email уже зарегистрирован' });

  const hash = bcrypt.hashSync(pass, 10);
  const info = db.prepare('INSERT INTO users (name,email,pass,role) VALUES (?,?,?,?)')
    .run(name, email, hash, 'user');

  const token = crypto.randomBytes(24).toString('hex');
  db.prepare('INSERT INTO sessions (token,user_id,created_at) VALUES (?,?,?)')
    .run(token, info.lastInsertRowid, new Date().toISOString());

  res.cookie('token', token, { httpOnly: true });
  res.json({ id: info.lastInsertRowid, name, email, role: 'user' });
});

router.post('/login', (req, res) => {
  const { email, pass } = req.body;
  if (!email || !pass) return res.status(400).json({ error: 'Заполните все поля' });

  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !bcrypt.compareSync(pass, user.pass)) {
    return res.status(401).json({ error: 'Неверный email или пароль' });
  }

  const token = crypto.randomBytes(24).toString('hex');
  db.prepare('INSERT INTO sessions (token,user_id,created_at) VALUES (?,?,?)')
    .run(token, user.id, new Date().toISOString());

  res.cookie('token', token, { httpOnly: true });
  res.json({ id: user.id, name: user.name, email: user.email, role: user.role });
});

router.post('/logout', (req, res) => {
  const token = req.cookies.token;
  if (token) db.prepare('DELETE FROM sessions WHERE token=?').run(token);
  res.clearCookie('token');
  res.json({ ok: true });
});

router.get('/me', (req, res) => {
  const user = currentUser(req);
  res.json(user || null);
});

module.exports = router;
