const express = require('express');
const db = require('../db');
const { currentUser } = require('./helpers');

const router = express.Router();

router.get('/', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  res.json(db.prepare('SELECT * FROM stickers ORDER BY id').all());
});

router.post('/', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  const { text, color, x, y } = req.body;
  const info = db.prepare('INSERT INTO stickers (text,color,x,y) VALUES (?,?,?,?)')
    .run(text, color, x, y);
  res.json(db.prepare('SELECT * FROM stickers WHERE id=?').get(info.lastInsertRowid));
});

router.put('/:id', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  const { x, y } = req.body;
  db.prepare('UPDATE stickers SET x=?,y=? WHERE id=?').run(x, y, req.params.id);
  res.json({ ok: true });
});

router.delete('/:id', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  db.prepare('DELETE FROM stickers WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;