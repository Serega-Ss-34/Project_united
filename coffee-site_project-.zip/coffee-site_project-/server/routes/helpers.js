const db = require('../db');

function currentUser(req) {
  const token = req.cookies.token;
  if (!token) return null;
  const row = db.prepare(
    'SELECT u.id,u.name,u.email,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?'
  ).get(token);
  return row || null;
}

module.exports = { currentUser };