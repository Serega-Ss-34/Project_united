const express = require('express');
const db = require('../db');
const { currentUser } = require('./helpers');

const router = express.Router();

function withItems(order) {
  const items = db.prepare('SELECT product_id AS id,name,cat,price,qty FROM order_items WHERE order_id=?').all(order.id);
  return { ...order, items };
}

router.get('/', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  const orders = db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 40').all();
  res.json(orders.map(withItems));
});

router.get('/stats', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  const orders = db.prepare('SELECT * FROM orders').all();
  const items = db.prepare('SELECT * FROM order_items').all();
  res.json({ orders: orders.map(withItems), items });
});

router.post('/', (req, res) => {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: 'Нужна авторизация' });

  const { items } = req.body;
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'Пустой заказ' });

  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  const date = new Date().toISOString();

  const create = db.transaction(() => {
    const info = db.prepare('INSERT INTO orders (date,customer,total) VALUES (?,?,?)')
      .run(date, user.name, total);
    const insert = db.prepare('INSERT INTO order_items (order_id,product_id,name,cat,price,qty) VALUES (?,?,?,?,?,?)');
    items.forEach(i => insert.run(info.lastInsertRowid, i.id, i.name, i.cat, i.price, i.qty));
    return info.lastInsertRowid;
  });

  const id = create();
  const order = db.prepare('SELECT * FROM orders WHERE id=?').get(id);
  res.json(withItems(order));
});

module.exports = router;