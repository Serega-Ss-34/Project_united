const express = require('express');
const db = require('../db');
const { currentUser } = require('./helpers');

const router = express.Router();

router.get('/', (req, res) => {
  res.json(db.prepare('SELECT * FROM products ORDER BY id').all());
});

router.post('/', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  const p = req.body;
  const info = db.prepare(
    'INSERT INTO products (name,cat,price,icon,spec,desc,full) VALUES (?,?,?,?,?,?,?)'
  ).run(p.name, p.cat, p.price, p.icon, p.spec, p.desc, p.full);
  res.json(db.prepare('SELECT * FROM products WHERE id=?').get(info.lastInsertRowid));
});

router.put('/:id', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  const p = req.body;
  db.prepare(
    'UPDATE products SET name=?,cat=?,price=?,icon=?,spec=?,desc=?,full=? WHERE id=?'
  ).run(p.name, p.cat, p.price, p.icon, p.spec, p.desc, p.full, req.params.id);
  res.json(db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id));
});

router.delete('/:id', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  db.prepare('DELETE FROM products WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;