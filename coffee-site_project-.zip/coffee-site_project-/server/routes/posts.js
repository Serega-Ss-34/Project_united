const express = require('express');
const db = require('../db');
const { currentUser } = require('./helpers');

const router = express.Router();

router.get('/', (req, res) => {
  res.json(db.prepare('SELECT * FROM posts ORDER BY date DESC').all());
});

router.post('/', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  const p = req.body;
  const date = new Date().toISOString().slice(0, 10);
  const info = db.prepare('INSERT INTO posts (date,title,excerpt,text) VALUES (?,?,?,?)')
    .run(date, p.title, p.excerpt, p.text);
  res.json(db.prepare('SELECT * FROM posts WHERE id=?').get(info.lastInsertRowid));
});

router.put('/:id', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  const p = req.body;
  db.prepare('UPDATE posts SET title=?,excerpt=?,text=? WHERE id=?')
    .run(p.title, p.excerpt, p.text, req.params.id);
  res.json(db.prepare('SELECT * FROM posts WHERE id=?').get(req.params.id));
});

router.delete('/:id', (req, res) => {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });

  db.prepare('DELETE FROM posts WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;