const path = require('path');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const db = new Database(path.join(__dirname, 'coffee.db'));
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    pass TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user'
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    cat TEXT NOT NULL,
    price INTEGER NOT NULL,
    icon TEXT,
    spec TEXT,
    desc TEXT,
    full TEXT
  );

  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    title TEXT NOT NULL,
    excerpt TEXT,
    text TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    customer TEXT NOT NULL,
    total INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER,
    name TEXT NOT NULL,
    cat TEXT,
    price INTEGER NOT NULL,
    qty INTEGER NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS stickers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    color TEXT NOT NULL,
    x INTEGER NOT NULL,
    y INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

function seed() {
  const count = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (count > 0) return;

  const admin = db.prepare('INSERT INTO users (name,email,pass,role) VALUES (?,?,?,?)');
  admin.run('Администратор', 'admin@kofe-doma.ru', bcrypt.hashSync('admin123', 10), 'admin');

  const products = [
    { name: 'Эспрессо', cat: 'Напитки', price: 180, icon: 'cup', spec: '60 мл',
      desc: 'Классический двойной шот из смеси арабики и робусты.',
      full: 'Двойной шот на свежемолотом зерне нашей обжарки. Плотное тело, густая крема с ореховым оттенком и долгое шоколадное послевкусие.\nПодаётся с бокалом воды, чтобы вкус раскрылся полностью.' },
    { name: 'Капучино', cat: 'Напитки', price: 260, icon: 'cup', spec: '200 мл',
      desc: 'Эспрессо, плотная молочная пена, мягкий сливочный вкус.',
      full: 'Равные части эспрессо, горячего молока и воздушной пены. Мягкий, сладковатый напиток, который подходит для утра и для долгого разговора.\nМожно заменить обычное молоко на безлактозное.' },
    { name: 'Флэт уайт', cat: 'Напитки', price: 290, icon: 'cup', spec: '160 мл',
      desc: 'Двойной рестретто с бархатным молоком.',
      full: 'Более крепкий и насыщенный, чем капучино: двойной рестретто и тонкий слой микропены. Хорош для тех, кто любит чувствовать вкус кофе.' },
    { name: 'Кофе по-домашнему', cat: 'Напитки', price: 230, icon: 'turka', spec: '150 мл',
      desc: 'Наш фирменный кофе, сваренный в турке на песке.',
      full: 'Рецепт, ради которого и появилась наша кофейня. Мелкий помол, медленный нагрев на песке, щепотка корицы и кардамона.\nПодаётся в маленькой чашке вместе с кусочком горького шоколада.' },
    { name: 'Колумбия Супремо', cat: 'Зерно', price: 890, icon: 'sack', spec: '250 г',
      desc: 'Зерно с нотками карамели и тёмного шоколада.',
      full: 'Моносорт арабики с высокогорных плантаций Колумбии. Средняя обжарка, сбалансированный вкус: карамель, тёмный шоколад, лёгкая цитрусовая кислотность.\nПодходит для эспрессо, турки и френч-пресса. Помол делаем бесплатно по вашему выбору.' },
    { name: 'Эфиопия Иргачефф', cat: 'Зерно', price: 1190, icon: 'sack', spec: '250 г',
      desc: 'Цветочный аромат и яркая цитрусовая кислотность.',
      full: 'Классика Эфиопии: аромат жасмина и бергамота, во вкусе чёрный чай и лимон. Светлая обжарка, которая лучше всего раскрывается в фильтре и воронке.' },
    { name: 'Круассан сливочный', cat: 'Выпечка', price: 190, icon: 'croissant', spec: '90 г',
      desc: 'Слоёный круассан на сливочном масле, выпекается ежедневно.',
      full: 'Хрустящая корочка, нежная слоистая внутренность и натуральное сливочное масло в составе. Пекарь начинает работу в шесть утра, поэтому к открытию круассаны ещё тёплые.' },
    { name: 'Чизкейк Нью-Йорк', cat: 'Выпечка', price: 340, icon: 'cake', spec: '140 г',
      desc: 'Плотный сливочный чизкейк на песочной основе.',
      full: 'Классический рецепт на сливочном сыре, с хрустящей песочной основой. Не слишком сладкий, отлично сочетается с чёрным кофе или эспрессо.' }
  ];
  const insertProduct = db.prepare('INSERT INTO products (name,cat,price,icon,spec,desc,full) VALUES (@name,@cat,@price,@icon,@spec,@desc,@full)');
  products.forEach(p => insertProduct.run(p));

  const posts = [
    { date: '2026-10-02', title: 'Как мы обжариваем зерно',
      excerpt: 'Рассказываем, как проходит обжарка каждой партии и почему мы не торопимся.',
      text: 'Каждая партия проходит пробную обжарку и каппинг. Мы выбираем профиль, который раскрывает природную сладость зерна и сохраняет чистоту вкуса.\n\nОкончательная обжарка занимает около двенадцати минут при строгом контроле температуры.' },
    { date: '2026-10-09', title: 'Эспрессо и фильтр: в чём разница',
      excerpt: 'Два способа приготовления и два разных характера одного и того же зерна.',
      text: 'Эспрессо готовится под давлением за 25–30 секунд и даёт концентрированный напиток. Фильтр заваривается дольше и мягче, лучше раскрывает кислотность.\n\nВыбор способа зависит от сорта зерна и вашего настроения.' },
    { date: '2026-10-16', title: 'Открытие осеннего меню',
      excerpt: 'Новые авторские напитки и выпечка собственного производства.',
      text: 'С октября в меню появились авторские напитки на основе эфиопской арабики, а также новая выпечка собственного производства. Приходите на дегустацию в субботу.' }
  ];
  const insertPost = db.prepare('INSERT INTO posts (date,title,excerpt,text) VALUES (@date,@title,@excerpt,@text)');
  posts.forEach(p => insertPost.run(p));

  const insertSticker = db.prepare('INSERT INTO stickers (text,color,x,y) VALUES (?,?,?,?)');
  insertSticker.run('Заказать зерно Эфиопия', 's-a', 40, 40);
  insertSticker.run('Проверить остатки молока', 's-b', 300, 90);

  const insertOrder = db.prepare('INSERT INTO orders (date,customer,total) VALUES (?,?,?)');
  const insertItem = db.prepare('INSERT INTO order_items (order_id,product_id,name,cat,price,qty) VALUES (?,?,?,?,?,?)');
  const allProducts = db.prepare('SELECT * FROM products').all();

  for (let d = 29; d >= 0; d--) {
    const n = 2 + ((d * 7) % 5);
    for (let i = 0; i < n; i++) {
      const p = allProducts[(d + i * 3) % allProducts.length];
      const q = 1 + ((d + i) % 3);
      const date = new Date();
      date.setDate(date.getDate() - d);
      const order = insertOrder.run(date.toISOString(), 'Гость', p.price * q);
      insertItem.run(order.lastInsertRowid, p.id, p.name, p.cat, p.price, q);
    }
  }
}

seed();

module.exports = db;