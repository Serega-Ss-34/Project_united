const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');

const app = express();
app.use((req, res, next) => {
  console.log(req.method, req.url);
  next();
});
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cookieParser());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/posts', require('./routes/posts'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/stickers', require('./routes/stickers'));

app.use(express.static(path.join(__dirname, '..', 'public')));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Ошибка сервера' });
});

app.listen(PORT, () => {
  console.log('Сервер запущен: http://localhost:' + PORT);
});
