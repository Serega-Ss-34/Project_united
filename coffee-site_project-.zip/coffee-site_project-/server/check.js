const db = require('better-sqlite3')('coffee.db');

console.log('\n--- ТАБЛИЦЫ В БАЗЕ ---');
console.log(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all());

console.log('\n--- ПОЛЬЗОВАТЕЛИ (пароли зашифрованы) ---');
console.log(db.prepare('SELECT id, name, email, pass, role FROM users').all());

console.log('\n--- ПОСЛЕДНИЕ 3 ЗАКАЗА ---');
console.log(db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 3').all());

console.log('\n--- ТОВАРЫ ---');
console.log(db.prepare('SELECT id, name, price FROM products LIMIT 3').all());

db.close();