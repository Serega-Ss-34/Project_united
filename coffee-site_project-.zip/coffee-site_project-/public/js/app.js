var activeCat = 'Все';

function renderCatalog() {
  api('GET', '/products').then(function (products) {
    var cats = ['Все'];
    products.forEach(function (p) {
      if (cats.indexOf(p.cat) === -1) cats.push(p.cat);
    });

    var filters = document.getElementById('filters');
    filters.innerHTML = cats.map(function (c) {
      return '<button class="chip ' + (c === activeCat ? 'active' : '') + '" data-c="' + esc(c) + '">' + esc(c) + '</button>';
    }).join('');

    filters.querySelectorAll('.chip').forEach(function (b) {
      b.onclick = function () {
        activeCat = b.dataset.c;
        renderCatalog();
      };
    });

    var list = activeCat === 'Все' ? products : products.filter(function (p) { return p.cat === activeCat; });
    var grid = document.getElementById('grid');
    grid.innerHTML = list.map(cardHTML).join('');
    bindAdd(grid);
  });
}

function renderBlog() {
  api('GET', '/posts').then(function (posts) {
    var box = document.getElementById('posts');
    box.innerHTML = posts.map(function (p) {
      var excerpt = p.excerpt || (p.text.split('\n')[0].slice(0, 130) + '…');
      return '<article class="post" data-post="' + p.id + '">' +
        '<time>' + fmtDate(p.date) + '</time>' +
        '<h3>' + esc(p.title) + '</h3>' +
        '<p>' + esc(excerpt) + '</p>' +
        '<span class="more">Читать ' + icon('arrow') + '</span>' +
      '</article>';
    }).join('');

    box.querySelectorAll('[data-post]').forEach(function (el) {
      el.onclick = function () {
        var p = posts.find(function (x) { return x.id === +el.dataset.post; });
        var paragraphs = p.text.split('\n').filter(Boolean).map(function (t) {
          return '<p>' + esc(t) + '</p>';
        }).join('');

        openModal(
          '<div class="article">' +
            '<span class="tag">' + fmtDate(p.date) + '</span>' +
            '<h3 style="margin-top:8px">' + esc(p.title) + '</h3>' +
            (p.excerpt ? '<p class="excerpt">' + esc(p.excerpt) + '</p>' : '') +
            paragraphs +
          '</div>',
          true
        );
      };
    });
  });
}

renderCatalog();
renderBlog();