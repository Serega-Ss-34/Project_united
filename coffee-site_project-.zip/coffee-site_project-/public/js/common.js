var ICONS = {
  logo: '<path d="M8.5 10h7l1.2 8.2a1 1 0 0 1-1 1.1H8.3a1 1 0 0 1-1-1.1L8.5 10z"/><path d="M9.5 10c0-2 .6-3.4 1.2-4.5h2.6c.6 1.1 1.2 2.5 1.2 4.5"/><path d="M10.7 5.5h2.6M10.7 5.5L9 4"/><path d="M16.4 12.5h2.6l1.5 4"/>',
  turka: '<path d="M8.5 10h7l1.2 8.2a1 1 0 0 1-1 1.1H8.3a1 1 0 0 1-1-1.1L8.5 10z"/><path d="M9.5 10c0-2 .6-3.4 1.2-4.5h2.6c.6 1.1 1.2 2.5 1.2 4.5"/><path d="M10.7 5.5h2.6M10.7 5.5L9 4"/><path d="M16.4 12.5h2.6l1.5 4"/>',
  cup: '<path d="M5 9h11v4.5a5.5 5.5 0 0 1-5.5 5.5A5.5 5.5 0 0 1 5 13.5V9z"/><path d="M16 10.5h1.2a2.3 2.3 0 0 1 0 4.6H15.3"/><path d="M3 21.5h16"/><path d="M8 3.5c0 1.2 1 1.2 1 2.4M12 3.5c0 1.2 1 1.2 1 2.4"/>',
  bean: '<ellipse cx="12" cy="12" rx="6" ry="9" transform="rotate(35 12 12)"/><path d="M8 6c4 2 4 10 8 12"/>',
  sack: '<path d="M8 4h8l1 3c2 2 3 5 3 9a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3c0-4 1-7 3-9l1-3z"/><path d="M8 4c1 1 2 1 4 1s3 0 4-1"/><path d="M10 13c1-1.2 3.2-.4 4 1.2s-.2 2.6-1.6 2.6S9 15 10 13z"/>',
  croissant: '<path d="M3 15c1-5 5-8 9-8s8 3 9 8c-1.5 1-3 .5-4-1-1.5 1.5-3.5 2-5 2s-3.5-.5-5-2c-1 1.5-2.5 2-4 1z"/><path d="M9 7.5l1.5 5M15 7.5l-1.5 5"/>',
  cake: '<path d="M3 10l9-4 9 4-9 4z"/><path d="M3 10v5l9 4 9-4v-5M12 14v5"/>',
  cart: '<path d="M3 4h3l2.5 11h9.5l2-8H7"/><circle cx="10" cy="19" r="1.4"/><circle cx="17" cy="19" r="1.4"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  arrow: '<path d="M4 12h16M14 6l6 6-6 6"/>',
  back: '<path d="M20 12H4M10 6l-6 6 6 6"/>',
  chart: '<path d="M4 20V4M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
  box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4V7z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
  note: '<path d="M5 3h14v12l-5 6H5V3z"/><path d="M14 21v-6h5"/>',
  doc: '<path d="M6 3h9l4 4v14H6V3z"/><path d="M9 11h7M9 15h7"/>',
  receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3z"/><path d="M9 8h6M9 12h6"/>',
  out: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/><path d="M14 11v6"/>',
  edit: '<path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/><path d="M15 5l4 4"/>',
  download: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  home: '<path d="M4 11l8-7 8 7v9H4v-9z"/>'
};

function icon(name) {
  return '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round">' + ICONS[name] + '</svg>';
}

var SHOP = 'Кофе по-домашнему';

function api(method, url, body) {
  return fetch('/api' + url, {
    method: method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    body: body ? JSON.stringify(body) : undefined
  }).then(function (r) {
    return r.json().then(function (data) {
      if (!r.ok) throw new Error(data.error || 'Ошибка запроса');
      return data;
    });
  });
}

function money(n) {
  return Number(n).toLocaleString('ru-RU') + ' ₽';
}

function toast(msg) {
  var t = document.querySelector('.toast');
  if (!t) {
    t = document.createElement('div');
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(function () { t.classList.remove('show'); }, 2200);
}

function fmtDate(s) {
  return new Date(s).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
}

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
  });
}

function cardHTML(p, i) {
  var href = 'product.html?id=' + p.id;
  return '<article class="card">' +
    '<a href="' + href + '" class="card-art art-' + (i % 3) + '">' +
      '<span class="num">№ ' + String(p.id).padStart(2, '0') + '</span>' +
      '<span class="medal">' + icon(p.icon || 'cup') + '</span>' +
    '</a>' +
    '<div class="card-body">' +
      '<span class="tag">' + esc(p.cat) + (p.spec ? ' · ' + esc(p.spec) : '') + '</span>' +
      '<h3><a href="' + href + '">' + esc(p.name) + '</a></h3>' +
      '<p>' + esc(p.desc) + '</p>' +
      '<div class="card-foot">' +
        '<b>' + money(p.price) + '</b>' +
        '<button class="btn btn-sm" data-add="' + p.id + '">' + icon('plus') + 'В корзину</button>' +
      '</div>' +
    '</div>' +
  '</article>';
}

function bindAdd(scope) {
  scope.querySelectorAll('[data-add]').forEach(function (btn) {
    btn.onclick = function () { addToCart(+btn.dataset.add, 1); };
  });
}

function receiptHTML(o) {
  var d = new Date(o.date);
  var itemsHTML = o.items.map(function (i) {
    return '<div class="r"><span>' + esc(i.name) + ' × ' + i.qty + '</span><span>' + money(i.price * i.qty) + '</span></div>';
  }).join('');

  return '<div class="receipt">' +
    '<h4>' + SHOP + '</h4>' +
    '<div class="c">ул. Ленина, 10</div><hr>' +
    '<div class="r"><span>Чек №' + o.id + '</span><span>' +
      d.toLocaleDateString('ru-RU') + ' ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) +
    '</span></div><hr>' +
    itemsHTML +
    '<hr><div class="r big"><span>ИТОГО</span><span>' + money(o.total) + '</span></div>' +
    '<hr><div class="c">Спасибо за заказ!</div>' +
  '</div>';
}

function receiptText(o) {
  var W = 36;
  var d = new Date(o.date);

  function line(a, b) {
    return a + ' '.repeat(Math.max(1, W - a.length - b.length)) + b;
  }
  function center(s) {
    return ' '.repeat(Math.max(0, Math.floor((W - s.length) / 2))) + s;
  }
  var rule = '-'.repeat(W);

  var lines = [
    center(SHOP.toUpperCase()),
    center('ул. Ленина, 10'),
    rule,
    line('Чек №' + o.id, d.toLocaleDateString('ru-RU') + ' ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })),
    rule
  ];

  o.items.forEach(function (i) {
    lines.push(line(i.name + ' x ' + i.qty, money(i.price * i.qty)));
  });

  lines.push(rule);
  lines.push(line('ИТОГО', money(o.total)));
  lines.push(rule);
  lines.push(center('Спасибо за заказ!'));
  lines.push('');

  return lines.join('\r\n');
}

function downloadReceipt(o) {
  var blob = new Blob(['\uFEFF' + receiptText(o)], { type: 'text/plain;charset=utf-8' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'check-' + o.id + '.txt';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
}

function receiptModal(o, title) {
  var w = openModal(
    '<h3>' + (title || 'Чек') + '</h3>' +
    receiptHTML(o) +
    '<button class="btn" id="dl">' + icon('download') + 'Скачать чек</button>'
  );
  w.querySelector('#dl').onclick = function () { downloadReceipt(o); };
}

function openModal(html, wide) {
  closeModal();

  var wrap = document.createElement('div');
  wrap.className = 'modal-wrap';
  wrap.id = 'modal';
  wrap.innerHTML =
    '<div class="modal ' + (wide ? 'wide' : '') + '">' +
      '<button class="modal-x" aria-label="Закрыть">' + icon('x') + '</button>' +
      html +
    '</div>';

  wrap.addEventListener('mousedown', function (e) {
    if (e.target === wrap) closeModal();
  });
  wrap.querySelector('.modal-x').onclick = closeModal;
  document.body.appendChild(wrap);
  return wrap;
}

function closeModal() {
  var m = document.getElementById('modal');
  if (m) m.remove();
}