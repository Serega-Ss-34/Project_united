var root = document.getElementById('root');

api('GET', '/auth/me').then(function (user) {
  if (!user || user.role !== 'admin') {
    showLogin();
  } else {
    startAdmin();
  }
});

function showLogin() {
  root.innerHTML =
    '<div class="denied"><div>' +
      '<span class="logo" style="justify-content:center">' + icon('logo') + SHOP + '</span>' +
      '<h2>Доступ ограничен</h2>' +
      '<p>Войдите как администратор.<br>Демо-доступ: admin@kofe-doma.ru / admin123</p>' +
      '<form id="f" style="max-width:320px;margin:0 auto;text-align:left">' +
        '<div class="field"><label>Email</label><input name="email" type="email" required></div>' +
        '<div class="field"><label>Пароль</label><input name="pass" type="password" required></div>' +
        '<div class="err" id="err"></div>' +
        '<button class="btn" style="width:100%">Войти</button>' +
      '</form>' +
      '<p style="margin-top:20px"><a href="index.html" style="color:var(--accent2)">← На сайт</a></p>' +
    '</div></div>';

  document.getElementById('f').onsubmit = function (e) {
    e.preventDefault();
    var f = Object.fromEntries(new FormData(e.target));

    api('POST', '/auth/login', f).then(function (user) {
      if (user.role !== 'admin') {
        document.getElementById('err').textContent = 'Недостаточно прав';
        return;
      }
      location.reload();
    }).catch(function (err) {
      document.getElementById('err').textContent = err.message;
    });
  };
}

function startAdmin() {
  var views = [
    ['stats', 'Статистика', 'chart'],
    ['products', 'Товары', 'box'],
    ['blog', 'Контент', 'doc'],
    ['orders', 'Заказы', 'receipt'],
    ['stickers', 'Стикеры', 'note']
  ];

  var navHTML = views.map(function (v) {
    return '<button data-v="' + v[0] + '">' + icon(v[2]) + v[1] + '</button>';
  }).join('');

  root.innerHTML =
    '<div class="admin">' +
      '<aside class="side">' +
        '<div class="logo">' + icon('logo') + SHOP + '</div>' +
        '<nav>' + navHTML + '</nav>' +
        '<div class="bottom">' +
          '<a class="btn btn-ghost btn-sm" href="index.html">' + icon('home') + 'На сайт</a>' +
          '<button class="btn btn-ghost btn-sm" id="out">' + icon('out') + 'Выйти</button>' +
        '</div>' +
      '</aside>' +
      '<div class="main" id="main"></div>' +
    '</div>';

  document.getElementById('out').onclick = function () {
    api('POST', '/auth/logout').then(function () { location.href = 'index.html'; });
  };

  var navButtons = root.querySelectorAll('nav button');
  navButtons.forEach(function (b) {
    b.onclick = function () { show(b.dataset.v); };
  });

  var viewsMap = { stats: stats, products: products, blog: blog, orders: orders, stickers: stickers };

  function show(name) {
    navButtons.forEach(function (b) {
      b.classList.toggle('active', b.dataset.v === name);
    });
    viewsMap[name](document.getElementById('main'));
  }

  window.refresh = function () { show(currentView); };
  var currentView = 'stats';
  show(currentView);
}

function stats(m) {
  api('GET', '/orders/stats').then(function (data) {
    var orders = data.orders;

    var revenue = orders.reduce(function (s, o) { return s + o.total; }, 0);
    var avg = orders.length ? Math.round(revenue / orders.length) : 0;
    var units = orders.reduce(function (s, o) {
      return s + o.items.reduce(function (a, i) { return a + i.qty; }, 0);
    }, 0);

    var days = [];
    for (var i = 13; i >= 0; i--) {
      var d = new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);
      days.push({ d: d, v: 0 });
    }

    orders.forEach(function (o) {
      var od = new Date(o.date);
      od.setHours(0, 0, 0, 0);
      var day = days.find(function (x) { return x.d.getTime() === od.getTime(); });
      if (day) day.v += o.total;
    });

    var max = Math.max.apply(null, days.map(function (d) { return d.v; }).concat([1]));
    var W = 640, H = 260, pl = 46, pb = 28, pt = 14;
    var bw = (W - pl) / days.length;
    var bars = '';

    for (var g = 0; g <= 4; g++) {
      var y = pt + (H - pt - pb) * g / 4;
      bars += '<line x1="' + pl + '" x2="' + W + '" y1="' + y + '" y2="' + y + '" stroke="#3d1414"/>' +
        '<text x="' + (pl - 8) + '" y="' + (y + 4) + '" text-anchor="end" fill="#a38b85" font-size="11">' +
        Math.round(max * (4 - g) / 4 / 100) / 10 + 'k</text>';
    }

    days.forEach(function (day, idx) {
      var h = (H - pt - pb) * day.v / max;
      var x = pl + idx * bw + bw * 0.18;
      bars += '<rect x="' + x + '" y="' + (H - pb - h) + '" width="' + (bw * 0.64) + '" height="' + h + '" fill="#cc4444">' +
        '<title>' + day.d.toLocaleDateString('ru-RU') + ': ' + money(day.v) + '</title></rect>';
      if (idx % 2 === 0) {
        bars += '<text x="' + (x + bw * 0.32) + '" y="' + (H - 8) + '" text-anchor="middle" fill="#a38b85" font-size="11">' +
          day.d.getDate() + '</text>';
      }
    });

    var catSum = {}, topSum = {};
    orders.forEach(function (o) {
      o.items.forEach(function (i) {
        catSum[i.cat] = (catSum[i.cat] || 0) + i.price * i.qty;
        if (!topSum[i.name]) topSum[i.name] = { name: i.name, qty: 0, sum: 0 };
        topSum[i.name].qty += i.qty;
        topSum[i.name].sum += i.price * i.qty;
      });
    });

    var colors = ['#cc4444', '#8fa08a', '#b9775f', '#c9c1b0'];
    var entries = Object.entries(catSum);
    var total = entries.reduce(function (s, e) { return s + e[1]; }, 0) || 1;

    var startAngle = -Math.PI / 2;
    var arcs = '';

    entries.forEach(function (e, idx) {
      var endAngle = startAngle + 2 * Math.PI * e[1] / total;
      var R = 90, r = 56, c = 110;
      function point(a, rr) {
        return (c + rr * Math.cos(a)).toFixed(1) + ' ' + (c + rr * Math.sin(a)).toFixed(1);
      }
      var big = (endAngle - startAngle) > Math.PI ? 1 : 0;
      arcs += '<path d="M' + point(startAngle, R) +
        ' A' + R + ' ' + R + ' 0 ' + big + ' 1 ' + point(endAngle - 0.01, R) +
        ' L' + point(endAngle - 0.01, r) +
        ' A' + r + ' ' + r + ' 0 ' + big + ' 0 ' + point(startAngle, r) +
        'Z" fill="' + colors[idx % 4] + '"/>';
      startAngle = endAngle;
    });

    var topList = Object.values(topSum).sort(function (a, b) { return b.sum - a.sum; }).slice(0, 6);
    var topMax = topList.length ? topList[0].sum : 1;

    var legendHTML = entries.map(function (e, idx) {
      return '<div><i style="background:' + colors[idx % 4] + '"></i>' +
        esc(e[0]) + ' — ' + Math.round(e[1] / total * 100) + '%</div>';
    }).join('');

    var topHTML = topList.map(function (t) {
      return '<tr><td>' + esc(t.name) + '</td><td>' + t.qty + '</td>' +
        '<td><div class="bar-cell"><i style="width:' + Math.round(t.sum / topMax * 120) + 'px"></i>' +
        money(t.sum) + '</div></td></tr>';
    }).join('');

    m.innerHTML =
      '<h2>Статистика продаж</h2><p class="lead">Аналитика за последние 30 дней</p>' +
      '<div class="kpis">' +
        '<div class="kpi"><span>Выручка</span><b>' + money(revenue) + '</b></div>' +
        '<div class="kpi"><span>Заказов</span><b>' + orders.length + '</b></div>' +
        '<div class="kpi"><span>Средний чек</span><b>' + money(avg) + '</b></div>' +
        '<div class="kpi"><span>Единиц продано</span><b>' + units + '</b></div>' +
      '</div>' +
      '<div class="panels">' +
        '<div class="panel"><h3>Выручка по дням</h3>' +
          '<svg viewBox="0 0 ' + W + ' ' + H + '">' + bars + '</svg></div>' +
        '<div class="panel"><h3>По категориям</h3>' +
          '<svg viewBox="0 0 220 220" style="max-width:220px;margin:0 auto">' + arcs + '</svg>' +
          '<div class="legend">' + legendHTML + '</div></div>' +
      '</div>' +
      '<div class="panel"><h3>Популярные товары</h3>' +
        '<table><tr><th>Товар</th><th>Продано</th><th>Выручка</th></tr>' + topHTML + '</table></div>';
  });
}

function products(m) {
  api('GET', '/products').then(function (list) {
    var rowsHTML = list.map(function (p) {
      return '<tr><td>' + esc(p.name) + '</td><td>' + esc(p.cat) + '</td><td>' + money(p.price) + '</td>' +
        '<td style="text-align:right">' +
          '<button class="btn" data-e="' + p.id + '" title="Редактировать">' + icon('edit') + '</button>' +
          '<button class="btn btn-danger" data-d="' + p.id + '" title="Удалить">' + icon('trash') + '</button>' +
        '</td></tr>';
    }).join('');

    m.innerHTML =
      '<h2>Товары</h2><p class="lead">Управление каталогом</p>' +
      '<div class="toolbar"><span>Всего позиций: ' + list.length + '</span>' +
        '<button class="btn btn-sm" id="add">' + icon('plus') + 'Добавить</button></div>' +
      '<div class="panel"><table>' +
        '<tr><th>Название</th><th>Категория</th><th>Цена</th><th></th></tr>' +
        rowsHTML +
      '</table></div>';

    m.querySelector('#add').onclick = function () { openProductForm(); };
    m.querySelectorAll('[data-e]').forEach(function (b) {
      b.onclick = function () { openProductForm(list.find(function (p) { return p.id === +b.dataset.e; })); };
    });
    m.querySelectorAll('[data-d]').forEach(function (b) {
      b.onclick = function () {
        if (!confirm('Удалить товар?')) return;
        api('DELETE', '/products/' + b.dataset.d).then(function () { refresh(); });
      };
    });
  });

  function openProductForm(p) {
    p = p || { name: '', cat: 'Напитки', price: '', desc: '', full: '', spec: '', icon: 'cup' };

    var iconOptions = [['cup', 'Чашка'], ['turka', 'Турка'], ['sack', 'Мешок зерна'], ['bean', 'Зерно'], ['croissant', 'Круассан'], ['cake', 'Десерт']];
    var cats = ['Напитки', 'Зерно', 'Выпечка'];
    var catsHTML = cats.map(function (c) { return '<option ' + (c === p.cat ? 'selected' : '') + '>' + c + '</option>'; }).join('');
    var iconsHTML = iconOptions.map(function (i) { return '<option value="' + i[0] + '" ' + (i[0] === p.icon ? 'selected' : '') + '>' + i[1] + '</option>'; }).join('');

    var w = openModal(
      '<h3>' + (p.id ? 'Редактирование' : 'Новый товар') + '</h3>' +
      '<form id="pf">' +
        '<div class="field"><label>Название</label><input name="name" required value="' + esc(p.name) + '"></div>' +
        '<div class="field"><label>Категория</label><select name="cat">' + catsHTML + '</select></div>' +
        '<div class="field"><label>Цена, ₽</label><input name="price" type="number" min="1" required value="' + p.price + '"></div>' +
        '<div class="field"><label>Объём / вес</label><input name="spec" value="' + esc(p.spec) + '"></div>' +
        '<div class="field"><label>Иконка</label><select name="icon">' + iconsHTML + '</select></div>' +
        '<div class="field"><label>Краткое описание</label><input name="desc" required value="' + esc(p.desc) + '"></div>' +
        '<div class="field"><label>Полное описание</label><textarea name="full">' + esc(p.full) + '</textarea></div>' +
        '<button class="btn">Сохранить</button>' +
      '</form>'
    );

    w.querySelector('#pf').onsubmit = function (e) {
      e.preventDefault();
      var f = Object.fromEntries(new FormData(e.target));
      f.price = +f.price;

      var method = p.id ? 'PUT' : 'POST';
      var url = p.id ? '/products/' + p.id : '/products';

      api(method, url, f).then(function () {
        closeModal();
        refresh();
        toast('Сохранено');
      }).catch(function (err) { toast(err.message); });
    };
  }
}

function blog(m) {
  api('GET', '/posts').then(function (list) {
    var rowsHTML = list.map(function (p) {
      return '<tr><td>' + esc(p.title) + '</td><td>' + fmtDate(p.date) + '</td>' +
        '<td style="text-align:right">' +
          '<button class="btn" data-e="' + p.id + '" title="Редактировать">' + icon('edit') + '</button>' +
          '<button class="btn btn-danger" data-d="' + p.id + '" title="Удалить">' + icon('trash') + '</button>' +
        '</td></tr>';
    }).join('');

    m.innerHTML =
      '<h2>Контент</h2><p class="lead">Статьи блога</p>' +
      '<div class="toolbar"><span>Публикаций: ' + list.length + '</span>' +
        '<button class="btn btn-sm" id="add">' + icon('plus') + 'Новая статья</button></div>' +
      '<div class="panel"><table>' +
        '<tr><th>Заголовок</th><th>Дата</th><th></th></tr>' + rowsHTML +
      '</table></div>';

    m.querySelector('#add').onclick = function () { openPostForm(); };
    m.querySelectorAll('[data-e]').forEach(function (b) {
      b.onclick = function () { openPostForm(list.find(function (p) { return p.id === +b.dataset.e; })); };
    });
    m.querySelectorAll('[data-d]').forEach(function (b) {
      b.onclick = function () {
        if (!confirm('Удалить статью?')) return;
        api('DELETE', '/posts/' + b.dataset.d).then(function () { refresh(); });
      };
    });
  });

  function openPostForm(p) {
    p = p || { title: '', excerpt: '', text: '' };

    var w = openModal(
      '<h3>' + (p.id ? 'Редактирование' : 'Новая статья') + '</h3>' +
      '<form id="pf">' +
        '<div class="field"><label>Заголовок</label><input name="title" required value="' + esc(p.title) + '"></div>' +
        '<div class="field"><label>Краткое описание</label><input name="excerpt" required value="' + esc(p.excerpt) + '"></div>' +
        '<div class="field"><label>Текст статьи</label><textarea name="text" required>' + esc(p.text) + '</textarea></div>' +
        '<button class="btn">Сохранить</button>' +
      '</form>', true
    );

    w.querySelector('#pf').onsubmit = function (e) {
      e.preventDefault();
      var f = Object.fromEntries(new FormData(e.target));

      var method = p.id ? 'PUT' : 'POST';
      var url = p.id ? '/posts/' + p.id : '/posts';

      api(method, url, f).then(function () {
        closeModal();
        refresh();
        toast('Сохранено');
      }).catch(function (err) { toast(err.message); });
    };
  }
}

function orders(m) {
  api('GET', '/orders').then(function (list) {
    var rowsHTML = list.map(function (o) {
      return '<tr><td>' + o.id + '</td>' +
        '<td>' + new Date(o.date).toLocaleDateString('ru-RU') + '</td>' +
        '<td>' + esc(o.customer) + '</td>' +
        '<td>' + money(o.total) + '</td>' +
        '<td style="text-align:right"><button class="btn btn-ghost btn-sm" data-r="' + o.id + '">Чек</button></td></tr>';
    }).join('');

    m.innerHTML =
      '<h2>Заказы</h2><p class="lead">Последние 40 заказов</p>' +
      '<div class="panel"><table>' +
        '<tr><th>№</th><th>Дата</th><th>Клиент</th><th>Сумма</th><th></th></tr>' + rowsHTML +
      '</table></div>';

    m.querySelectorAll('[data-r]').forEach(function (b) {
      b.onclick = function () {
        var o = list.find(function (x) { return x.id === +b.dataset.r; });
        receiptModal(o);
      };
    });
  });
}

function stickers(m) {
  api('GET', '/stickers').then(function (list) {
    m.innerHTML =
      '<h2>Стикеры</h2><p class="lead">Рабочие заметки</p>' +
      '<div class="add-sticker">' +
        '<input id="st" placeholder="Текст заметки">' +
        '<select id="sc">' +
          '<option value="s-a">Золотой</option>' +
          '<option value="s-b">Серый</option>' +
          '<option value="s-c">Терракотовый</option>' +
          '<option value="s-d">Зелёный</option>' +
        '</select>' +
        '<button class="btn btn-sm" id="sa">' + icon('plus') + 'Добавить</button>' +
      '</div>' +
      '<div class="board" id="board"></div>';

    var board = m.querySelector('#board');

    function draw() {
      board.innerHTML = '';
      list.forEach(function (s) {
        var el = document.createElement('div');
        el.className = 'sticker ' + s.color;
        el.style.left = s.x + 'px';
        el.style.top = s.y + 'px';
        el.innerHTML = '<p>' + esc(s.text) + '</p><button aria-label="Удалить">' + icon('x') + '</button>';

        el.querySelector('button').onclick = function (ev) {
          ev.stopPropagation();
          api('DELETE', '/stickers/' + s.id).then(function () {
            list = list.filter(function (x) { return x.id !== s.id; });
            draw();
          });
        };

        el.addEventListener('pointerdown', function (e) {
          if (e.target.closest('button')) return;

          var offsetX = e.clientX - s.x;
          var offsetY = e.clientY - s.y;

          el.classList.add('drag');
          el.setPointerCapture(e.pointerId);
          board.appendChild(el);

          function onMove(ev) {
            s.x = Math.max(0, Math.min(board.clientWidth - el.offsetWidth, ev.clientX - offsetX));
            s.y = Math.max(0, Math.min(board.clientHeight - el.offsetHeight, ev.clientY - offsetY));
            el.style.left = s.x + 'px';
            el.style.top = s.y + 'px';
          }

          function onUp() {
            el.classList.remove('drag');
            el.removeEventListener('pointermove', onMove);
            el.removeEventListener('pointerup', onUp);
            api('PUT', '/stickers/' + s.id, { x: s.x, y: s.y });
          }

          el.addEventListener('pointermove', onMove);
          el.addEventListener('pointerup', onUp);
        });

        board.appendChild(el);
      });
    }

    m.querySelector('#sa').onclick = function () {
      var text = m.querySelector('#st').value.trim();
      if (!text) return;

      api('POST', '/stickers', {
        text: text,
        color: m.querySelector('#sc').value,
        x: 30 + (list.length * 24) % 300,
        y: 30 + (list.length * 24) % 300
      }).then(function (saved) {
        list.push(saved);
        m.querySelector('#st').value = '';
        draw();
      });
    };

    draw();
  });
}