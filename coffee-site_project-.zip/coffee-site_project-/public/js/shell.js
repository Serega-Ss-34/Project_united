var cart = [];

document.getElementById('site-header').outerHTML =
  '<header class="header"><div class="container">' +
    '<a href="index.html" class="logo">' + icon('logo') + SHOP + '</a>' +
    '<nav class="nav">' +
      '<a href="index.html#catalog">Каталог</a>' +
      '<a href="index.html#blog">Блог</a>' +
      '<a href="index.html#about">О нас</a>' +
    '</nav>' +
    '<div class="actions">' +
      '<button class="icon-btn" id="btnUser">' + icon('user') + '<span id="userLabel">Войти</span></button>' +
      '<button class="icon-btn" id="btnCart">' + icon('cart') + 'Корзина <span class="badge" id="cartCount">0</span></button>' +
    '</div>' +
  '</div></header>';

document.getElementById('site-footer').outerHTML =
  '<footer class="footer"><div class="container">' +
    '<span>© 2026 ' + SHOP + '. Учебный проект.</span>' +
    '<a href="admin.html">Панель администратора</a>' +
  '</div></footer>' +
  '<div class="overlay" id="overlay"></div>' +
  '<aside class="drawer" id="drawer">' +
    '<div class="drawer-head">' +
      '<h3>Корзина</h3>' +
      '<button class="icon-btn" id="closeCart" aria-label="Закрыть">' + icon('x') + '</button>' +
    '</div>' +
    '<div class="drawer-body" id="cartBody"></div>' +
    '<div class="drawer-foot" id="cartFoot"></div>' +
  '</aside>';

function saveCart() {
  localStorage.setItem('kd_cart', JSON.stringify(cart));
  renderCart();
}

function addToCart(id, qty) {
  qty = qty || 1;
  api('GET', '/products').then(function (products) {
    var p = products.find(function (x) { return x.id === id; });
    if (!p) return;

    var item = cart.find(function (x) { return x.id === id; });
    if (item) item.qty += qty;
    else cart.push({ id: p.id, name: p.name, cat: p.cat, price: p.price, qty: qty });

    saveCart();
    toast('Добавлено: ' + p.name);
  });
}

function changeQty(id, delta) {
  var item = cart.find(function (x) { return x.id === id; });
  item.qty += delta;
  if (item.qty <= 0) {
    cart = cart.filter(function (x) { return x.id !== id; });
  }
  saveCart();
}

function cartTotal() {
  return cart.reduce(function (sum, i) { return sum + i.price * i.qty; }, 0);
}

function renderCart() {
  var count = cart.reduce(function (sum, i) { return sum + i.qty; }, 0);
  document.getElementById('cartCount').textContent = count;

  var body = document.getElementById('cartBody');
  var foot = document.getElementById('cartFoot');

  if (!cart.length) {
    body.innerHTML = '<div class="empty">Корзина пуста</div>';
    foot.innerHTML = '';
    return;
  }

  body.innerHTML = cart.map(function (i) {
    return '<div class="line-item">' +
      '<div><h4><a href="product.html?id=' + i.id + '">' + esc(i.name) + '</a></h4>' +
      '<small>' + money(i.price) + '</small></div>' +
      '<div class="line-sum">' + money(i.price * i.qty) + '</div>' +
      '<div class="qty">' +
        '<button data-m="' + i.id + '" aria-label="Меньше">' + icon('minus') + '</button>' +
        '<span>' + i.qty + '</span>' +
        '<button data-p="' + i.id + '" aria-label="Больше">' + icon('plus') + '</button>' +
      '</div>' +
    '</div>';
  }).join('');

  body.querySelectorAll('[data-m]').forEach(function (b) {
    b.onclick = function () { changeQty(+b.dataset.m, -1); };
  });
  body.querySelectorAll('[data-p]').forEach(function (b) {
    b.onclick = function () { changeQty(+b.dataset.p, 1); };
  });

  foot.innerHTML =
    '<div class="total-row"><span>Итого</span><b>' + money(cartTotal()) + '</b></div>' +
    '<button class="btn" id="checkout">Оформить заказ</button>';
  document.getElementById('checkout').onclick = checkout;
}

var drawer = document.getElementById('drawer');
var overlay = document.getElementById('overlay');

function toggleCart(open) {
  drawer.classList.toggle('open', open);
  overlay.classList.toggle('open', open);
}

document.getElementById('btnCart').onclick = function () { toggleCart(true); };
document.getElementById('closeCart').onclick = function () { toggleCart(false); };
overlay.onclick = function () { toggleCart(false); };

function checkout() {
  api('GET', '/auth/me').then(function (user) {
    if (!user) {
      toggleCart(false);
      toast('Для заказа необходимо войти');
      openAuth();
      return;
    }

    api('POST', '/orders', { items: cart }).then(function (order) {
      cart = [];
      saveCart();
      toggleCart(false);
      receiptModal(order, 'Заказ оформлен');
    }).catch(function (err) {
      toast(err.message);
    });
  });
}

function updateUser() {
  api('GET', '/auth/me').then(function (user) {
    document.getElementById('userLabel').textContent = user ? user.name : 'Войти';
  });
}

document.getElementById('btnUser').onclick = function () {
  api('GET', '/auth/me').then(function (user) {
    if (!user) {
      openAuth();
      return;
    }

    var html = '<h3>' + esc(user.name) + '</h3>' +
      '<p style="color:var(--muted);margin-bottom:22px">' + esc(user.email) + '</p>';

    if (user.role === 'admin') {
      html += '<a class="btn" href="admin.html" style="margin-bottom:10px">Панель администратора</a>';
    }
    html += '<button class="btn btn-ghost" id="logout">Выйти</button>';

    var w = openModal(html);
    w.querySelector('#logout').onclick = function () {
      api('POST', '/auth/logout').then(function () {
        updateUser();
        closeModal();
        toast('Вы вышли');
      });
    };
  });
};

function openAuth(mode) {
  mode = mode || 'login';
  var isReg = mode === 'reg';

  var html = '<div class="tabs">' +
    '<button class="tab ' + (!isReg ? 'active' : '') + '" data-t="login">Вход</button>' +
    '<button class="tab ' + (isReg ? 'active' : '') + '" data-t="reg">Регистрация</button>' +
  '</div>' +
  '<form id="authForm">' +
    (isReg ? '<div class="field"><label>Имя</label><input name="name" required></div>' : '') +
    '<div class="field"><label>Email</label><input name="email" type="email" required></div>' +
    '<div class="field"><label>Пароль</label><input name="pass" type="password" minlength="6" required></div>' +
    '<div class="err" id="err"></div>' +
    '<button class="btn" type="submit">' + (isReg ? 'Создать аккаунт' : 'Войти') + '</button>' +
  '</form>';

  var w = openModal(html);

  w.querySelectorAll('.tab').forEach(function (t) {
    t.onclick = function () { openAuth(t.dataset.t); };
  });

  w.querySelector('#authForm').onsubmit = function (e) {
    e.preventDefault();
    var f = Object.fromEntries(new FormData(e.target));
    var url = isReg ? '/auth/register' : '/auth/login';

    api('POST', url, f).then(function (user) {
      updateUser();
      closeModal();
      toast('Добро пожаловать, ' + user.name);
    }).catch(function (err) {
      w.querySelector('#err').textContent = err.message;
    });
  };
}

cart = JSON.parse(localStorage.getItem('kd_cart') || '[]');
renderCart();
updateUser();