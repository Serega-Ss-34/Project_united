document.querySelector('.back').innerHTML = icon('back') + 'Вернуться в каталог';

var pid = +new URLSearchParams(location.search).get('id');
var box = document.getElementById('product');

api('GET', '/products').then(function (allProducts) {
  var prod = allProducts.find(function (x) { return x.id === pid; });

  if (!prod) {
    box.innerHTML = '<div class="empty" style="padding:120px 0">' +
      'Товар не найден.<br>' +
      '<a href="index.html#catalog" style="color:var(--accent2)">Вернуться в каталог</a>' +
    '</div>';
    return;
  }

  document.title = prod.name + ' — ' + SHOP;
  var qty = 1;
  var fullParagraphs = (prod.full || prod.desc || '').split('\n').filter(Boolean);

  box.innerHTML =
    '<div class="product">' +
      '<div class="product-art">' +
        '<span class="num">№ ' + String(prod.id).padStart(2, '0') + '</span>' +
        '<span class="medal">' + icon(prod.icon || 'cup') + '</span>' +
      '</div>' +
      '<div class="product-info">' +
        '<span class="tag">' + esc(prod.cat) + '</span>' +
        '<h1>' + esc(prod.name) + '</h1>' +
        '<div class="price">' + money(prod.price) + '</div>' +
        '<p class="lead-text">' + esc(prod.desc) + '</p>' +
        '<div class="full-text">' +
          fullParagraphs.map(function (t) { return '<p>' + esc(t) + '</p>'; }).join('') +
        '</div>' +
        '<div class="specs">' +
          '<div><span>Категория</span><b>' + esc(prod.cat) + '</b></div>' +
          (prod.spec ? '<div><span>Объём / вес</span><b>' + esc(prod.spec) + '</b></div>' : '') +
          '<div><span>Артикул</span><b>KD-' + String(prod.id).padStart(4, '0') + '</b></div>' +
        '</div>' +
        '<div class="buy">' +
          '<div class="qty">' +
            '<button id="qm" aria-label="Меньше">' + icon('minus') + '</button>' +
            '<span id="qv">1</span>' +
            '<button id="qp" aria-label="Больше">' + icon('plus') + '</button>' +
          '</div>' +
          '<button class="btn" id="buy">В корзину</button>' +
        '</div>' +
      '</div>' +
    '</div>';

  var qv = document.getElementById('qv');

  document.getElementById('qm').onclick = function () {
    qty = Math.max(1, qty - 1);
    qv.textContent = qty;
  };
  document.getElementById('qp').onclick = function () {
    qty = Math.min(20, qty + 1);
    qv.textContent = qty;
  };
  document.getElementById('buy').onclick = function () {
    addToCart(prod.id, qty);
  };

  var others = allProducts.filter(function (p) { return p.id !== prod.id; })
    .sort(function (a, b) { return (b.cat === prod.cat) - (a.cat === prod.cat); })
    .slice(0, 3);

  if (others.length) {
    document.getElementById('relatedWrap').style.display = 'block';
    var rel = document.getElementById('related');
    rel.innerHTML = others.map(cardHTML).join('');
    bindAdd(rel);
  }
});