"""Генерация PDF: акт приёма-передачи и квитанция с QR-кодом."""
import io
import os

from reportlab.graphics import renderPDF
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

_FONTS = os.path.join(os.path.dirname(__file__), "fonts")
_registered = False


def _fonts():
    global _registered
    if not _registered:
        pdfmetrics.registerFont(TTFont("DV", os.path.join(_FONTS, "DejaVuSans.ttf")))
        pdfmetrics.registerFont(TTFont("DV-B", os.path.join(_FONTS, "DejaVuSans-Bold.ttf")))
        _registered = True


def _money(v):
    s = f"{float(v):,.2f}".replace(",", " ").replace(".", ",")
    return (s[:-3] if s.endswith(",00") else s) + " руб."


def _wrap(text, font, size, width):
    lines, cur = [], ""
    for word in text.replace("\n", " ").split():
        trial = f"{cur} {word}".strip()
        if pdfmetrics.stringWidth(trial, font, size) <= width:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines or [""]


def build_receipt(order, parts, total, track_url):
    _fonts()
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4
    left, right = 20 * 28.35 / 10, w - 20 * 28.35 / 10
    y = h - 60

    c.setFont("DV-B", 16)
    c.drawString(left, y, f"Акт приёма-передачи и квитанция № {order['id']}")
    y -= 18
    c.setFont("DV", 9)
    c.drawString(left, y, f"Ремонтная мастерская · дата приёма: {order['created_at']} (UTC)")
    y -= 28

    def row(label, value):
        nonlocal y
        c.setFont("DV-B", 10)
        c.drawString(left, y, label)
        c.setFont("DV", 10)
        for line in _wrap(str(value), "DV", 10, right - left - 150):
            c.drawString(left + 150, y, line)
            y -= 14
        y -= 2

    row("Клиент:", order["client_name"])
    row("Телефон:", order["client_phone"] or "—")
    row("Устройство:", f"{order['device_type']}, {order['device_model']}")
    row("Неисправность:", order["fault_type"])
    row("Описание:", order["description"])
    row("Статус:", order["status_title"])
    row("Мастер:", order["master_name"] or "не назначен")
    y -= 8

    c.setFont("DV-B", 11)
    c.drawString(left, y, "Стоимость")
    y -= 16
    c.setFont("DV", 10)
    c.drawString(left, y, "Работы")
    c.drawRightString(right, y, _money(order["labor_cost"]))
    y -= 14
    for p in parts:
        c.drawString(left, y, f"{p['name']} × {p['quantity']}")
        c.drawRightString(right, y, _money(p["quantity"] * p["unit_price"]))
        y -= 14
    c.line(left, y + 6, right, y + 6)
    y -= 6
    c.setFont("DV-B", 12)
    c.drawString(left, y, "Итого")
    c.drawRightString(right, y, _money(total))
    y -= 50

    # QR-код со ссылкой на публичную страницу статуса
    size = 110
    d = Drawing(size, size)
    qr = QrCodeWidget(track_url)
    x1, y1, x2, y2 = qr.getBounds()
    d.add(qr)
    d.scale(size / (x2 - x1), size / (y2 - y1))
    d.width = d.height = size
    renderPDF.draw(d, c, left, y - size + 10)
    c.setFont("DV", 9)
    c.drawString(left + size + 14, y - 20, "Отсканируйте QR-код, чтобы проверить статус заявки:")
    for i, line in enumerate(_wrap(track_url, "DV", 8, right - left - size - 14)):
        c.setFont("DV", 8)
        c.drawString(left + size + 14, y - 34 - 11 * i, line)
    y -= size + 40

    c.setFont("DV", 10)
    c.drawString(left, y, "Устройство сдал: ____________________")
    c.drawString(left + 270, y, "Устройство принял: ____________________")
    c.showPage()
    c.save()
    return buf.getvalue()
