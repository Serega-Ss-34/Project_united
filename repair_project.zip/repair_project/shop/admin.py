"""Панель администратора."""
import sqlite3
from datetime import date, timedelta

from flask import Blueprint, abort, flash, g, jsonify, redirect, render_template, request, url_for
from werkzeug.security import generate_password_hash

from . import db, logic, security, validators as v

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.before_request
@security.login_required("admin")
def _guard():
    pass


@bp.route("/")
def dashboard():
    c = lambda sql, a=(): db.query(sql, a, one=True)["c"]
    stats = {
        "new": c("SELECT COUNT(*) c FROM orders WHERE master_id IS NULL AND status_id = 1"),
        "active": c("SELECT COUNT(*) c FROM orders o JOIN statuses s ON s.id=o.status_id WHERE s.code != 'issued'"),
        "ready": c("SELECT COUNT(*) c FROM orders o JOIN statuses s ON s.id=o.status_id WHERE s.code = 'ready'"),
        "low": c("SELECT COUNT(*) c FROM parts WHERE quantity <= min_quantity"),
        "total": c("SELECT COUNT(*) c FROM orders"),
    }
    latest = db.query(logic.ORDER_SELECT + " ORDER BY o.id DESC LIMIT 8")
    return render_template("admin/dashboard.html", stats=stats, latest=latest)


# ---------- заявки ----------
@bp.route("/orders")
def orders():
    status = request.args.get("status", "")
    master = request.args.get("master", "")
    q = (request.args.get("q") or "").strip()[:60]
    sql, args = logic.ORDER_SELECT + " WHERE 1=1", []
    if status:
        sql += " AND s.code = ?"
        args.append(status)
    if master == "none":
        sql += " AND o.master_id IS NULL"
    elif master.isdigit():
        sql += " AND o.master_id = ?"
        args.append(int(master))
    if q:
        if q.isdigit():
            sql += " AND (o.id = ? OR c.full_name LIKE ? OR o.device_model LIKE ?)"
            args += [int(q), f"%{q}%", f"%{q}%"]
        else:
            sql += " AND (c.full_name LIKE ? OR o.device_model LIKE ? OR c.email LIKE ?)"
            args += [f"%{q}%"] * 3
    sql += " ORDER BY o.id DESC LIMIT 300"
    return render_template(
        "admin/orders.html", orders=db.query(sql, args), status=status, master=master, q=q,
        statuses=db.query("SELECT * FROM statuses ORDER BY sort_order"),
        masters=db.query("SELECT id, full_name FROM users WHERE role='master' ORDER BY full_name"))


@bp.route("/kanban")
def kanban():
    statuses = db.query("SELECT * FROM statuses ORDER BY sort_order")
    cards = db.query(logic.ORDER_SELECT + " ORDER BY o.updated_at DESC")
    columns = {s["code"]: [] for s in statuses}
    for o in cards:
        # выданные показываем только за последние 7 дней, чтобы доска не росла бесконечно
        if o["status_code"] == "issued" and (o["closed_at"] or "") < str(date.today() - timedelta(days=7)):
            continue
        columns[o["status_code"]].append(o)
    masters = db.query("SELECT id, full_name FROM users WHERE role='master' AND is_active=1 ORDER BY full_name")
    return render_template("admin/kanban.html", statuses=statuses, columns=columns, masters=masters)


@bp.route("/api/orders/<int:order_id>/status", methods=["POST"])
def api_status(order_id):
    order = logic.get_order(order_id)
    if order is None:
        return jsonify(error="Заявка не найдена"), 404
    data = request.get_json(silent=True) or {}
    try:
        logic.change_status(order, str(data.get("status", "")), g.user)
    except v.ValidationError as e:
        return jsonify(error=str(e)), 400
    return jsonify(ok=True)


# ---------- услуги ----------
def _service_fields(row=None):
    row = row or {}
    devs = [("", "— любое устройство —")] + [
        (d["id"], d["name"]) for d in db.query("SELECT * FROM device_types ORDER BY name")]
    return [
        dict(name="name", label="Название", type="text", value=row.get("name"), required=True, maxlength=120),
        dict(name="description", label="Описание", type="textarea", value=row.get("description")),
        dict(name="device_type_id", label="Тип устройства", type="select", options=devs,
             value=row.get("device_type_id") or ""),
        dict(name="price_from", label="Цена от, ₽", type="number", value=row.get("price_from"),
             required=True, step="0.01", min="0"),
        dict(name="price_to", label="Цена до, ₽", type="number", value=row.get("price_to"),
             required=True, step="0.01", min="0"),
        dict(name="duration_days", label="Срок, дней", type="number", value=row.get("duration_days", 1),
             required=True, min="1"),
        dict(name="is_active", label="Показывать в каталоге", type="checkbox",
             value=row.get("is_active", 1)),
    ]


def _service_data(f):
    name = v.text(f.get("name"), "Название", 2, 120)
    desc = v.clean(f.get("description"))[:1000] or None
    dev = None
    if f.get("device_type_id"):
        dev = v.integer(f.get("device_type_id"), "Тип устройства", 1)
        if not db.query("SELECT 1 FROM device_types WHERE id=?", (dev,), one=True):
            raise v.ValidationError("Тип устройства не найден")
    p1 = v.money(f.get("price_from"), "Цена от")
    p2 = v.money(f.get("price_to"), "Цена до")
    if p2 < p1:
        raise v.ValidationError("«Цена до» не может быть меньше «Цены от»")
    days = v.integer(f.get("duration_days"), "Срок", 1, 365)
    return (name, desc, dev, p1, p2, days, 1 if f.get("is_active") else 0)


@bp.route("/services")
def services():
    rows = db.query("SELECT s.*, dt.name AS device_type FROM services s "
                    "LEFT JOIN device_types dt ON dt.id = s.device_type_id ORDER BY s.id DESC")
    return render_template("admin/services.html", services=rows)


@bp.route("/services/new", methods=["GET", "POST"])
def service_new():
    if request.method == "POST":
        try:
            data = _service_data(request.form)
        except v.ValidationError as e:
            flash(str(e), "error")
            return render_template("admin/form.html", title="Новая услуга", fields=_service_fields(request.form),
                                   back=url_for("admin.services")), 400
        db.execute("INSERT INTO services (name, description, device_type_id, price_from, price_to, "
                   "duration_days, is_active) VALUES (?,?,?,?,?,?,?)", data)
        db.commit()
        flash("Услуга добавлена", "ok")
        return redirect(url_for("admin.services"))
    return render_template("admin/form.html", title="Новая услуга", fields=_service_fields(),
                           back=url_for("admin.services"))


@bp.route("/services/<int:sid>/edit", methods=["GET", "POST"])
def service_edit(sid):
    row = db.query("SELECT * FROM services WHERE id = ?", (sid,), one=True)
    if row is None:
        abort(404)
    if request.method == "POST":
        try:
            data = _service_data(request.form)
        except v.ValidationError as e:
            flash(str(e), "error")
            return render_template("admin/form.html", title="Редактирование услуги",
                                   fields=_service_fields(request.form), back=url_for("admin.services")), 400
        db.execute("UPDATE services SET name=?, description=?, device_type_id=?, price_from=?, price_to=?, "
                   "duration_days=?, is_active=? WHERE id=?", (*data, sid))
        db.commit()
        flash("Услуга сохранена", "ok")
        return redirect(url_for("admin.services"))
    return render_template("admin/form.html", title="Редактирование услуги",
                           fields=_service_fields(dict(row)), back=url_for("admin.services"))


@bp.route("/services/<int:sid>/delete", methods=["POST"])
def service_delete(sid):
    db.execute("DELETE FROM services WHERE id = ?", (sid,))  # в заявках service_id станет NULL
    db.commit()
    flash("Услуга удалена", "ok")
    return redirect(url_for("admin.services"))


# ---------- пользователи ----------
ROLES = [("client", "Клиент"), ("master", "Мастер"), ("admin", "Администратор")]


@bp.route("/users")
def users():
    rows = db.query(
        "SELECT u.*, (SELECT COUNT(*) FROM orders o WHERE o.client_id=u.id OR o.master_id=u.id) AS orders_count "
        "FROM users u ORDER BY u.role, u.full_name")
    return render_template("admin/users.html", users=rows, roles=dict(ROLES))


def _user_fields(row=None, creating=False):
    row = row or {}
    fields = [
        dict(name="full_name", label="ФИО", type="text", value=row.get("full_name"), required=True),
        dict(name="email", label="E-mail", type="email", value=row.get("email"), required=True),
        dict(name="phone", label="Телефон", type="text", value=row.get("phone")),
        dict(name="role", label="Роль", type="select", options=ROLES, value=row.get("role", "master")),
        dict(name="is_active", label="Активен", type="checkbox", value=row.get("is_active", 1)),
        dict(name="password", label="Пароль" if creating else "Новый пароль (пусто — не менять)",
             type="password", value="", required=creating),
    ]
    return fields


@bp.route("/users/new", methods=["GET", "POST"])
def user_new():
    back = url_for("admin.users")
    if request.method == "POST":
        f = request.form
        try:
            email = v.email(f.get("email"))
            if db.query("SELECT 1 FROM users WHERE email=?", (email,), one=True):
                raise v.ValidationError("Такой e-mail уже занят")
            name = v.text(f.get("full_name"), "ФИО", 2, 100)
            phone = v.phone(f.get("phone"))
            role = v.choice(f.get("role"), [r for r, _ in ROLES], "Роль")
            pwd = v.password(f.get("password"))
        except v.ValidationError as e:
            flash(str(e), "error")
            return render_template("admin/form.html", title="Новый пользователь",
                                   fields=_user_fields(f, True), back=back), 400
        db.execute("INSERT INTO users (email, password_hash, full_name, phone, role, is_active) "
                   "VALUES (?,?,?,?,?,?)",
                   (email, generate_password_hash(pwd), name, phone, role, 1 if f.get("is_active") else 0))
        db.commit()
        flash("Пользователь создан", "ok")
        return redirect(back)
    return render_template("admin/form.html", title="Новый пользователь",
                           fields=_user_fields(creating=True), back=back)


@bp.route("/users/<int:uid>/edit", methods=["GET", "POST"])
def user_edit(uid):
    row = db.query("SELECT * FROM users WHERE id = ?", (uid,), one=True)
    if row is None:
        abort(404)
    back = url_for("admin.users")
    if request.method == "POST":
        f = request.form
        try:
            email = v.email(f.get("email"))
            if db.query("SELECT 1 FROM users WHERE email=? AND id != ?", (email, uid), one=True):
                raise v.ValidationError("Такой e-mail уже занят")
            name = v.text(f.get("full_name"), "ФИО", 2, 100)
            phone = v.phone(f.get("phone"))
            role = v.choice(f.get("role"), [r for r, _ in ROLES], "Роль")
            active = 1 if f.get("is_active") else 0
            if uid == g.user["id"] and (role != "admin" or not active):
                raise v.ValidationError("Нельзя лишить прав или отключить самого себя")
            pwd = f.get("password") or ""
            if pwd:
                v.password(pwd)
        except v.ValidationError as e:
            flash(str(e), "error")
            return render_template("admin/form.html", title="Редактирование пользователя",
                                   fields=_user_fields(f), back=back), 400
        db.execute("UPDATE users SET email=?, full_name=?, phone=?, role=?, is_active=? WHERE id=?",
                   (email, name, phone, role, active, uid))
        if pwd:
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(pwd), uid))
        db.commit()
        flash("Пользователь сохранён", "ok")
        return redirect(back)
    return render_template("admin/form.html", title="Редактирование пользователя",
                           fields=_user_fields(dict(row)), back=back)


# ---------- склад ----------
def _part_fields(row=None):
    row = row or {}
    return [
        dict(name="name", label="Название", type="text", value=row.get("name"), required=True),
        dict(name="sku", label="Артикул", type="text", value=row.get("sku"), required=True),
        dict(name="quantity", label="Остаток, шт.", type="number", value=row.get("quantity", 0),
             required=True, min="0"),
        dict(name="min_quantity", label="Минимальный остаток", type="number",
             value=row.get("min_quantity", 1), required=True, min="0"),
        dict(name="unit_price", label="Цена за шт., ₽", type="number", value=row.get("unit_price"),
             required=True, step="0.01", min="0"),
    ]


def _part_data(f, pid=None):
    name = v.text(f.get("name"), "Название", 2, 120)
    sku = v.text(f.get("sku"), "Артикул", 1, 40)
    qty = v.integer(f.get("quantity"), "Остаток", 0, 1_000_000)
    mn = v.integer(f.get("min_quantity"), "Минимальный остаток", 0, 1_000_000)
    price = v.money(f.get("unit_price"), "Цена")
    dup = db.query("SELECT 1 FROM parts WHERE sku = ? AND id != ?", (sku, pid or 0), one=True)
    if dup:
        raise v.ValidationError("Запчасть с таким артикулом уже есть")
    return (name, sku, qty, mn, price)


@bp.route("/parts")
def parts():
    rows = db.query("SELECT * FROM parts ORDER BY (quantity <= min_quantity) DESC, name")
    return render_template("admin/parts.html", parts=rows)


@bp.route("/parts/new", methods=["GET", "POST"])
def part_new():
    back = url_for("admin.parts")
    if request.method == "POST":
        try:
            data = _part_data(request.form)
        except v.ValidationError as e:
            flash(str(e), "error")
            return render_template("admin/form.html", title="Новая запчасть",
                                   fields=_part_fields(request.form), back=back), 400
        db.execute("INSERT INTO parts (name, sku, quantity, min_quantity, unit_price) VALUES (?,?,?,?,?)", data)
        db.commit()
        flash("Запчасть добавлена", "ok")
        return redirect(back)
    return render_template("admin/form.html", title="Новая запчасть", fields=_part_fields(), back=back)


@bp.route("/parts/<int:pid>/edit", methods=["GET", "POST"])
def part_edit(pid):
    row = db.query("SELECT * FROM parts WHERE id = ?", (pid,), one=True)
    if row is None:
        abort(404)
    back = url_for("admin.parts")
    if request.method == "POST":
        try:
            data = _part_data(request.form, pid)
        except v.ValidationError as e:
            flash(str(e), "error")
            return render_template("admin/form.html", title="Редактирование запчасти",
                                   fields=_part_fields(request.form), back=back), 400
        db.execute("UPDATE parts SET name=?, sku=?, quantity=?, min_quantity=?, unit_price=? WHERE id=?",
                   (*data, pid))
        db.commit()
        flash("Запчасть сохранена", "ok")
        return redirect(back)
    return render_template("admin/form.html", title="Редактирование запчасти",
                           fields=_part_fields(dict(row)), back=back)


@bp.route("/parts/<int:pid>/restock", methods=["POST"])
def part_restock(pid):
    try:
        qty = v.integer(request.form.get("quantity"), "Количество", 1, 100000)
    except v.ValidationError as e:
        flash(str(e), "error")
        return redirect(url_for("admin.parts"))
    cur = db.execute("UPDATE parts SET quantity = quantity + ? WHERE id = ?", (qty, pid))
    if cur.rowcount == 0:
        abort(404)
    db.commit()
    flash(f"Склад пополнен на {qty} шт.", "ok")
    return redirect(url_for("admin.parts"))


@bp.route("/parts/<int:pid>/delete", methods=["POST"])
def part_delete(pid):
    try:
        db.execute("DELETE FROM parts WHERE id = ?", (pid,))
        db.commit()
        flash("Запчасть удалена", "ok")
    except sqlite3.IntegrityError:
        db.get_db().rollback()
        flash("Нельзя удалить: запчасть использована в заявках", "error")
    return redirect(url_for("admin.parts"))


# ---------- статистика ----------
@bp.route("/stats")
def stats():
    return render_template("admin/stats.html")


def _periods(kind):
    """Список ключей периодов (последние 30 дней или 12 месяцев) и формат strftime."""
    today = date.today()
    if kind == "day":
        keys = [(today - timedelta(days=i)).isoformat() for i in range(29, -1, -1)]
        return keys, "%Y-%m-%d"
    keys, y, m = [], today.year, today.month
    for _ in range(12):
        keys.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    return keys[::-1], "%Y-%m"


@bp.route("/api/stats")
def api_stats():
    kind = "day" if request.args.get("period") == "day" else "month"
    keys, fmt = _periods(kind)
    orders_by = {r["p"]: r["n"] for r in db.query(
        "SELECT strftime(?, created_at) p, COUNT(*) n FROM orders GROUP BY p", (fmt,))}
    revenue_by = {r["p"]: r["rev"] for r in db.query(
        "SELECT strftime(?, o.closed_at) p, SUM(o.labor_cost + COALESCE("
        "(SELECT SUM(op.quantity*op.unit_price) FROM order_parts op WHERE op.order_id=o.id),0)) rev "
        "FROM orders o WHERE o.closed_at IS NOT NULL GROUP BY p", (fmt,))}
    faults = db.query("SELECT ft.name, COUNT(o.id) n FROM fault_types ft LEFT JOIN orders o "
                      "ON o.fault_type_id = ft.id GROUP BY ft.id ORDER BY n DESC")
    load = db.query(
        "SELECT u.full_name, COUNT(o.id) n FROM users u LEFT JOIN orders o ON o.master_id = u.id "
        "AND o.status_id != (SELECT id FROM statuses WHERE code='issued') "
        "WHERE u.role='master' AND u.is_active=1 GROUP BY u.id ORDER BY n DESC")
    statuses = db.query("SELECT s.title, s.color, COUNT(o.id) n FROM statuses s LEFT JOIN orders o "
                        "ON o.status_id = s.id GROUP BY s.id ORDER BY s.sort_order")
    total_rev = sum(revenue_by.values())
    return jsonify(
        labels=keys,
        orders=[orders_by.get(k, 0) for k in keys],
        revenue=[round(revenue_by.get(k, 0), 2) for k in keys],
        faults={"labels": [r["name"] for r in faults], "values": [r["n"] for r in faults]},
        load={"labels": [r["full_name"] for r in load], "values": [r["n"] for r in load]},
        statuses={"labels": [r["title"] for r in statuses], "values": [r["n"] for r in statuses],
                  "colors": [r["color"] for r in statuses]},
        totals={"orders": sum(orders_by.get(k, 0) for k in keys), "revenue": round(sum(
            revenue_by.get(k, 0) for k in keys), 2), "all_revenue": round(total_rev, 2)},
    )
