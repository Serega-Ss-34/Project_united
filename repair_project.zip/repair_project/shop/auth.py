from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from . import db, security, validators as v

bp = Blueprint("auth", __name__)

# заглушка для выравнивания времени ответа, когда пользователь не найден
_DUMMY_HASH = generate_password_hash("dummy-password-1")


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        try:
            email = v.email(f.get("email"))
            name = v.text(f.get("full_name"), "ФИО", 2, 100)
            phone = v.phone(f.get("phone"), required=True)
            pwd = v.password(f.get("password"))
            if pwd != f.get("password2"):
                raise v.ValidationError("Пароли не совпадают")
            if db.query("SELECT 1 FROM users WHERE email = ?", (email,), one=True):
                raise v.ValidationError("Пользователь с таким e-mail уже существует")
        except v.ValidationError as e:
            flash(str(e), "error")
            return render_template("register.html", form=f), 400
        cur = db.execute(
            "INSERT INTO users (email, password_hash, full_name, phone, role) VALUES (?,?,?,?, 'client')",
            (email, generate_password_hash(pwd), name, phone),
        )
        db.commit()
        session.clear()
        session["uid"] = cur.lastrowid
        flash("Регистрация прошла успешно", "ok")
        return redirect(url_for("orders.cabinet"))
    return render_template("register.html", form={})


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = v.clean(request.form.get("email")).lower()
        pwd = request.form.get("password") or ""
        key = f"{request.remote_addr}|{email}"
        if security.too_many_attempts(key):
            flash("Слишком много неудачных попыток. Повторите через 5 минут.", "error")
            return render_template("login.html", form=request.form), 429
        user = db.query("SELECT * FROM users WHERE email = ?", (email,), one=True)
        ok = check_password_hash(user["password_hash"] if user else _DUMMY_HASH, pwd)
        if not (user and ok and user["is_active"]):
            security.register_failure(key)
            flash("Неверный e-mail или пароль", "error")
            return render_template("login.html", form=request.form), 401
        security.clear_failures(key)
        session.clear()  # защита от фиксации сессии
        session["uid"] = user["id"]
        target = security.safe_next(request.args.get("next"))
        return redirect(target or url_for(security.home_for(user)))
    return render_template("login.html", form={})


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("public.index"))
