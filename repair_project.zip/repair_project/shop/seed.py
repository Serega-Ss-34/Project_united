"""Демонстрационные данные: справочники, пользователи, услуги, склад и заявки за год."""
import random
from datetime import datetime, timedelta

from werkzeug.security import generate_password_hash

from . import db
from .logic import new_token

DEMO_PASSWORD = "Demo12345"
ADMIN = ("admin@repair.local", "Admin12345")


def seed():
    db.init_db()
    rnd = random.Random(7)
    conn = db.get_db()

    devices = ["Смартфон", "Ноутбук", "Планшет", "Телевизор", "Игровая консоль", "Стиральная машина"]
    faults = ["Не включается", "Разбит экран", "Не заряжается", "Перегрев / шум",
              "Попадание жидкости", "Программный сбой", "Другое"]
    conn.executemany("INSERT INTO device_types (name) VALUES (?)", [(d,) for d in devices])
    conn.executemany("INSERT INTO fault_types (name) VALUES (?)", [(f,) for f in faults])

    users = [
        (ADMIN[0], ADMIN[1], "Администратор Системы", "+7 900 000-00-01", "admin"),
        ("ivanov@repair.local", DEMO_PASSWORD, "Иванов Сергей Петрович", "+7 900 000-00-02", "master"),
        ("petrova@repair.local", DEMO_PASSWORD, "Петрова Анна Игоревна", "+7 900 000-00-03", "master"),
        ("sidorov@repair.local", DEMO_PASSWORD, "Сидоров Олег Викторович", "+7 900 000-00-04", "master"),
        ("client1@mail.ru", DEMO_PASSWORD, "Смирнов Алексей", "+7 913 111-22-33", "client"),
        ("client2@mail.ru", DEMO_PASSWORD, "Кузнецова Мария", "+7 913 222-33-44", "client"),
        ("client3@mail.ru", DEMO_PASSWORD, "Попов Дмитрий", "+7 913 333-44-55", "client"),
        ("client4@mail.ru", DEMO_PASSWORD, "Васильева Елена", "+7 913 444-55-66", "client"),
    ]
    for email, pwd, name, phone, role in users:
        conn.execute("INSERT INTO users (email, password_hash, full_name, phone, role) VALUES (?,?,?,?,?)",
                     (email, generate_password_hash(pwd), name, phone, role))
    masters = [2, 3, 4]
    clients = [5, 6, 7, 8]

    services = [
        ("Диагностика", "Выявление причины неисправности, составление сметы", None, 0, 500, 1),
        ("Замена экрана смартфона", "Оригинальные и аналоговые дисплеи", 1, 2500, 12000, 2),
        ("Замена аккумулятора", "Новый аккумулятор с гарантией 6 месяцев", 1, 1200, 3500, 1),
        ("Ремонт разъёма зарядки", "Замена или пайка разъёма", 1, 1000, 2500, 2),
        ("Чистка ноутбука от пыли", "Замена термопасты, чистка системы охлаждения", 2, 1200, 2000, 1),
        ("Замена матрицы ноутбука", "Подбор и установка матрицы", 2, 4500, 15000, 4),
        ("Установка Windows и драйверов", "Чистая установка ОС и ПО", 2, 1000, 1800, 1),
        ("Замена экрана планшета", "Стекло и дисплейный модуль", 3, 2800, 9000, 3),
        ("Ремонт подсветки телевизора", "Замена LED-линеек", 4, 3000, 8000, 5),
        ("Ремонт HDMI-порта консоли", "Замена порта, пайка", 5, 2500, 5000, 4),
        ("Замена термопасты консоли", "Профилактика перегрева", 5, 1500, 2500, 1),
        ("Замена подшипников стиральной машины", "Ремонт барабана", 6, 4500, 9000, 3),
    ]
    conn.executemany("INSERT INTO services (name, description, device_type_id, price_from, price_to, "
                     "duration_days) VALUES (?,?,?,?,?,?)", services)

    parts = [
        ("Дисплейный модуль смартфона", "DSP-PH-01", 8, 3, 3800),
        ("Аккумулятор смартфона", "BAT-PH-02", 15, 5, 900),
        ("Разъём зарядки Type-C", "CON-USC-03", 30, 10, 150),
        ("Матрица ноутбука 15.6", "MTX-NB-04", 3, 2, 5200),
        ("Термопаста 4 г", "THP-05", 25, 5, 250),
        ("Клавиатура ноутбука", "KBD-NB-06", 2, 3, 1400),
        ("LED-линейка ТВ 43\"", "LED-TV-07", 6, 2, 1800),
        ("HDMI-порт консоли", "HDM-CN-08", 10, 4, 350),
        ("Подшипник барабана (комплект)", "BRG-WM-09", 4, 2, 2100),
        ("SSD 256 ГБ", "SSD-256-10", 1, 2, 2600),
    ]
    conn.executemany("INSERT INTO parts (name, sku, quantity, min_quantity, unit_price) VALUES (?,?,?,?,?)", parts)

    models = {1: ["iPhone 12", "Samsung Galaxy A52", "Xiaomi Redmi Note 10", "Honor 9X"],
              2: ["Lenovo IdeaPad 3", "ASUS VivoBook 15", "HP Pavilion 14", "Acer Aspire 5"],
              3: ["iPad Air 4", "Samsung Tab S6", "Lenovo Tab M10"],
              4: ["LG 43UP75", "Samsung UE50", "Sony KD-49"],
              5: ["PlayStation 5", "Xbox Series S", "Nintendo Switch"],
              6: ["Bosch WAN2018", "LG F2J3", "Indesit IWSC"]}
    descs = ["Устройство перестало реагировать на кнопки после падения, требуется диагностика.",
             "Периодически выключается и сильно нагревается во время работы.",
             "Не заряжается от родного блока питания, разъём шатается.",
             "Треснул экран, сенсор работает с перебоями.",
             "Залили водой, после этого не включается совсем.",
             "Очень медленно работает и зависает, подозрение на вирусы."]

    now = datetime.now().replace(microsecond=0)
    statuses = {r["code"]: r["id"] for r in db.query("SELECT * FROM statuses")}
    order_codes = ["accepted", "diagnostics", "repair", "ready", "issued"]

    for i in range(70):
        if i >= 54:   # свежие заявки в разных статусах — для демонстрации канбана
            age_days = rnd.randint(0, 9)
            code = order_codes[(i - 54) % 4]
        else:
            age_days = int(rnd.triangular(8, 340, 60))
            code = "issued"
        created = now - timedelta(days=age_days, hours=rnd.randint(0, 20))
        dev = rnd.randint(1, 6)
        fault = rnd.choices(range(1, 8), weights=[18, 20, 14, 10, 6, 8, 4])[0]
        client = rnd.choice(clients)
        master = rnd.choice(masters) if code != "accepted" else None
        if i >= 54 and code == "accepted" and i % 2:
            master = None
        labor = rnd.choice([500, 1200, 1500, 2000, 2500, 3500, 4500]) if code in ("ready", "issued") else 0
        cur = conn.execute(
            "INSERT INTO orders (public_token, client_id, master_id, device_type_id, fault_type_id, "
            "device_model, description, status_id, labor_cost, created_at, updated_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (new_token(), client, master, dev, fault, rnd.choice(models[dev]), rnd.choice(descs),
             statuses[code], labor, created.strftime("%Y-%m-%d %H:%M:%S"), created.strftime("%Y-%m-%d %H:%M:%S")))
        oid = cur.lastrowid
        steps = order_codes[: order_codes.index(code) + 1]
        t = created
        for s in steps:
            conn.execute("INSERT INTO status_history (order_id, status_id, changed_by, changed_at) VALUES (?,?,?,?)",
                         (oid, statuses[s], master or client, t.strftime("%Y-%m-%d %H:%M:%S")))
            last = t
            t += timedelta(days=rnd.randint(0, 2), hours=rnd.randint(1, 8))
        upd = min(last, now).strftime("%Y-%m-%d %H:%M:%S")
        closed = upd if code == "issued" else None
        conn.execute("UPDATE orders SET updated_at=?, closed_at=? WHERE id=?", (upd, closed, oid))
        if code in ("ready", "issued") and rnd.random() < 0.7:
            p = rnd.randint(1, len(parts))
            conn.execute("INSERT INTO order_parts (order_id, part_id, quantity, unit_price) VALUES (?,?,?,?)",
                         (oid, p, 1, parts[p - 1][4]))
        if master and rnd.random() < 0.5:
            conn.execute("INSERT INTO order_comments (order_id, user_id, body, created_at) VALUES (?,?,?,?)",
                         (oid, master, "Диагностика выполнена, согласуем сроки ремонта.", upd))
    conn.commit()
