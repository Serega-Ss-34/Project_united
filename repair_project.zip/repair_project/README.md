# Ремонтная мастерская

Запуск (Python 3.9+), в папке проекта:

    py -m pip install -r requirements.txt
    py -m flask --app run seed
    py run.py

Открыть: http://127.0.0.1:5000

Вход:
- админ: admin@repair.local / Admin12345
- мастер: ivanov@repair.local / Demo12345
- клиент: client1@mail.ru / Demo12345

Тесты: py -m unittest discover -s tests -t .
