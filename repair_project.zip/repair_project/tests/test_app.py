"""Автотесты (unittest): функциональные, формы, граничные значения, права доступа.

Запуск:  python -m unittest discover -v tests
"""
import io
import os
import tempfile
import unittest

from PIL import Image
from werkzeug.security import generate_password_hash

from shop import create_app, db, security


def png_bytes(fmt="PNG"):
    buf = io.BytesIO()
    Image.new("RGB", (8, 8), "red").save(buf, fmt)
    buf.seek(0)
    return buf


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app({
            "TESTING": True,
            "DATABASE": os.path.join(self.tmp.name, "t.db"),
            "UPLOAD_FOLDER": os.path.join(self.tmp.name, "up"),
        })
        security._failed_logins.clear()
        with self.app.app_context():
            db.init_db()
            c = db.get_db()
            c.execute("INSERT INTO device_types (name) VALUES ('Смартфон')")
            c.execute("INSERT INTO fault_types (name) VALUES ('Не включается')")
            c.execute("INSERT INTO parts (name, sku, quantity, min_quantity, unit_price) "
                      "VALUES ('Аккумулятор', 'B-1', 5, 1, 900)")
            for email, name, role in [("admin@t.ru", "Админ Тестов", "admin"),
                                      ("m1@t.ru", "Мастер Один", "master"),
                                      ("m2@t.ru", "Мастер Два", "master"),
                                      ("c1@t.ru", "Клиент Один", "client"),
                                      ("c2@t.ru", "Клиент Два", "client")]:
                c.execute("INSERT INTO users (email, password_hash, full_name, phone, role) VALUES (?,?,?,?,?)",
                          (email, generate_password_hash("Passw0rd!"), name, "+7 900 111-22-33", role))
            c.commit()

    def tearDown(self):
        self.tmp.cleanup()

    # --- помощники ---
    def client(self, email=None):
        cl = self.app.test_client()
        with cl.session_transaction() as s:
            s["_csrf"] = "tok"
        if email:
            r = cl.post("/login", data={"email": email, "password": "Passw0rd!", "csrf_token": "tok"})
            self.assertEqual(r.status_code, 302, f"вход {email} не удался")
            with cl.session_transaction() as s:   # вход очищает сессию (защита от фиксации)
                s["_csrf"] = "tok"
        return cl

    def post(self, cl, url, **data):
        data["csrf_token"] = "tok"
        return cl.post(url, data=data, follow_redirects=True)

    def q(self, sql, args=()):
        with self.app.app_context():
            return [dict(r) for r in db.query(sql, args)]

    def make_order(self, cl, **over):
        data = dict(device_type_id="1", fault_type_id="1", device_model="iPhone 12",
                    description="Не включается после падения", csrf_token="tok")
        data.update(over)
        return cl.post("/orders/new", data=data)

    def new_order_id(self, email="c1@t.ru"):
        r = self.make_order(self.client(email))
        self.assertEqual(r.status_code, 302)
        return self.q("SELECT MAX(id) i FROM orders")[0]["i"]

    def user_id(self, email):
        return self.q("SELECT id FROM users WHERE email=?", (email,))[0]["id"]


class AuthTests(Base):
    def reg(self, **over):
        d = dict(full_name="Новый Клиент", email="new@t.ru", phone="+7 900 555-66-77",
                 password="Abcdef12", password2="Abcdef12", csrf_token="tok")
        d.update(over)
        return self.client().post("/register", data=d)

    def test_register_ok(self):
        self.assertEqual(self.reg().status_code, 302)
        self.assertEqual(self.q("SELECT role FROM users WHERE email='new@t.ru'")[0]["role"], "client")

    def test_register_password_stored_hashed(self):
        self.reg()
        h = self.q("SELECT password_hash FROM users WHERE email='new@t.ru'")[0]["password_hash"]
        self.assertNotIn("Abcdef12", h)

    def test_register_validation(self):
        for bad in (dict(email="no-at"), dict(password="short1", password2="short1"),
                    dict(password="onlyletters", password2="onlyletters"),
                    dict(password2="Different1"), dict(phone="abc"), dict(full_name="A"),
                    dict(email="c1@t.ru")):
            self.assertEqual(self.reg(**bad).status_code, 400, bad)

    def test_register_cannot_choose_role(self):
        self.reg(role="admin")
        self.assertEqual(self.q("SELECT role FROM users WHERE email='new@t.ru'")[0]["role"], "client")

    def test_login_wrong_password(self):
        r = self.client().post("/login", data={"email": "c1@t.ru", "password": "bad", "csrf_token": "tok"})
        self.assertEqual(r.status_code, 401)

    def test_login_rate_limit(self):
        cl = self.client()
        for _ in range(5):
            cl.post("/login", data={"email": "c1@t.ru", "password": "bad", "csrf_token": "tok"})
        r = cl.post("/login", data={"email": "c1@t.ru", "password": "Passw0rd!", "csrf_token": "tok"})
        self.assertEqual(r.status_code, 429)

    def test_inactive_user_cannot_login(self):
        with self.app.app_context():
            db.execute("UPDATE users SET is_active=0 WHERE email='c1@t.ru'")
            db.commit()
        r = self.client().post("/login", data={"email": "c1@t.ru", "password": "Passw0rd!", "csrf_token": "tok"})
        self.assertEqual(r.status_code, 401)

    def test_csrf_required(self):
        cl = self.app.test_client()
        self.assertEqual(cl.post("/login", data={"email": "c1@t.ru", "password": "Passw0rd!"}).status_code, 400)

    def test_open_redirect_blocked(self):
        cl = self.client()
        r = cl.post("/login?next=//evil.com", data={"email": "c1@t.ru", "password": "Passw0rd!", "csrf_token": "tok"})
        self.assertNotIn("evil.com", r.headers["Location"])

    def test_logout(self):
        cl = self.client("c1@t.ru")
        cl.post("/logout", data={"csrf_token": "tok"})
        self.assertEqual(cl.get("/cabinet").status_code, 302)


class AccessTests(Base):
    def test_anonymous_redirected(self):
        for url in ("/cabinet", "/admin/", "/master", "/orders/new"):
            self.assertEqual(self.client().get(url).status_code, 302, url)

    def test_role_isolation(self):
        c, m, a = self.client("c1@t.ru"), self.client("m1@t.ru"), self.client("admin@t.ru")
        self.assertEqual(c.get("/admin/").status_code, 403)
        self.assertEqual(c.get("/master").status_code, 403)
        self.assertEqual(m.get("/admin/orders").status_code, 403)
        self.assertEqual(m.get("/cabinet").status_code, 403)
        self.assertEqual(a.get("/admin/").status_code, 200)

    def test_public_pages(self):
        cl = self.client()
        self.assertEqual(cl.get("/").status_code, 200)
        self.assertEqual(cl.get("/services").status_code, 200)
        self.assertEqual(cl.get("/nope").status_code, 404)

    def test_sql_injection_in_search(self):
        cl = self.client()
        r = cl.get("/services?q=' OR 1=1; DROP TABLE users; --")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(self.q("SELECT * FROM users")), 5)


class OrderTests(Base):
    def test_create_order(self):
        oid = self.new_order_id()
        o = self.q("SELECT * FROM orders WHERE id=?", (oid,))[0]
        self.assertEqual(o["status_id"], 1)
        self.assertEqual(len(self.q("SELECT * FROM status_history WHERE order_id=?", (oid,))), 1)

    def test_order_validation_and_boundaries(self):
        cl = self.client("c1@t.ru")
        cases = [dict(description="короткое"),            # 8 символов < 10
                 dict(description="x" * 2001),             # > 2000
                 dict(device_model="A"),
                 dict(device_type_id="999"), dict(fault_type_id="abc"), dict(device_type_id=""),
                 dict(service_id="999")]
        for bad in cases:
            self.assertEqual(self.make_order(cl, **bad).status_code, 400, bad)
        # ровно на границах — принимается
        self.assertEqual(self.make_order(cl, description="x" * 10).status_code, 302)
        self.assertEqual(self.make_order(cl, description="x" * 2000).status_code, 302)

    def test_photo_upload(self):
        cl = self.client("c1@t.ru")
        data = dict(device_type_id="1", fault_type_id="1", device_model="Pixel 7",
                    description="Разбит экран, нужна замена", csrf_token="tok",
                    photos=(png_bytes(), "a.png"))
        self.assertEqual(cl.post("/orders/new", data=data, content_type="multipart/form-data").status_code, 302)
        self.assertEqual(len(self.q("SELECT * FROM order_photos")), 1)

    def test_fake_image_rejected(self):
        cl = self.client("c1@t.ru")
        data = dict(device_type_id="1", fault_type_id="1", device_model="Pixel 7",
                    description="Разбит экран, нужна замена", csrf_token="tok",
                    photos=(io.BytesIO(b"<?php evil ?>"), "shell.png"))
        self.assertEqual(cl.post("/orders/new", data=data, content_type="multipart/form-data").status_code, 400)
        self.assertEqual(len(self.q("SELECT * FROM orders")), 0)

    def test_too_many_photos(self):
        cl = self.client("c1@t.ru")
        data = dict(device_type_id="1", fault_type_id="1", device_model="Pixel 7",
                    description="Разбит экран, нужна замена", csrf_token="tok",
                    photos=[(png_bytes(), f"{i}.png") for i in range(4)])
        self.assertEqual(cl.post("/orders/new", data=data, content_type="multipart/form-data").status_code, 400)

    def test_client_sees_only_own_orders(self):
        oid = self.new_order_id("c1@t.ru")
        self.assertEqual(self.client("c1@t.ru").get(f"/orders/{oid}").status_code, 200)
        self.assertEqual(self.client("c2@t.ru").get(f"/orders/{oid}").status_code, 403)
        self.assertEqual(self.client("c2@t.ru").get(f"/orders/{oid}/receipt.pdf").status_code, 403)
        self.assertNotIn(f"#{oid}", self.client("c2@t.ru").get("/cabinet").get_data(as_text=True))

    def test_photo_access_control(self):
        cl = self.client("c1@t.ru")
        cl.post("/orders/new", content_type="multipart/form-data", data=dict(
            device_type_id="1", fault_type_id="1", device_model="Pixel 7",
            description="Разбит экран, нужна замена", csrf_token="tok", photos=(png_bytes(), "a.png")))
        self.assertEqual(cl.get("/photos/1").status_code, 200)
        self.assertEqual(self.client("c2@t.ru").get("/photos/1").status_code, 403)
        self.assertEqual(self.client().get("/photos/1").status_code, 302)

    def test_comment(self):
        oid = self.new_order_id()
        cl = self.client("c1@t.ru")
        self.post(cl, f"/orders/{oid}/comment", body="Позвоните мне")
        self.post(cl, f"/orders/{oid}/comment", body="   ")        # пустой — отклоняется
        self.assertEqual(len(self.q("SELECT * FROM order_comments")), 1)
        self.assertEqual(self.client("c2@t.ru").post(f"/orders/{oid}/comment",
                         data={"body": "hack", "csrf_token": "tok"}).status_code, 403)

    def test_receipt_pdf(self):
        oid = self.new_order_id()
        r = self.client("c1@t.ru").get(f"/orders/{oid}/receipt.pdf")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.data.startswith(b"%PDF"))

    def test_public_track_hides_personal_data(self):
        oid = self.new_order_id()
        token = self.q("SELECT public_token FROM orders WHERE id=?", (oid,))[0]["public_token"]
        html = self.client().get(f"/track/{token}").get_data(as_text=True)
        self.assertIn("Принята", html)
        self.assertNotIn("c1@t.ru", html)
        self.assertNotIn("Клиент Один", html)
        self.assertEqual(self.client().get("/track/unknown").status_code, 404)


class MasterTests(Base):
    def setUp(self):
        super().setUp()
        self.oid = self.new_order_id()
        self.a = self.client("admin@t.ru")
        self.post(self.a, f"/orders/{self.oid}/assign", master_id=str(self.user_id("m1@t.ru")))
        self.m = self.client("m1@t.ru")

    def test_assign_moves_to_diagnostics_and_lists_for_master(self):
        o = self.q("SELECT master_id, status_id FROM orders WHERE id=?", (self.oid,))[0]
        self.assertEqual(o["master_id"], self.user_id("m1@t.ru"))
        self.assertEqual(o["status_id"], 2)
        self.assertIn(f"#{self.oid}", self.m.get("/master").get_data(as_text=True))
        self.assertNotIn(f"#{self.oid}", self.client("m2@t.ru").get("/master").get_data(as_text=True))

    def test_other_master_forbidden(self):
        m2 = self.client("m2@t.ru")
        self.assertEqual(m2.get(f"/orders/{self.oid}").status_code, 403)
        self.assertEqual(m2.post(f"/orders/{self.oid}/status", data={"status": "repair", "csrf_token": "tok"}).status_code, 403)

    def test_client_cannot_change_status(self):
        c = self.client("c1@t.ru")
        self.assertEqual(c.post(f"/orders/{self.oid}/status", data={"status": "issued", "csrf_token": "tok"}).status_code, 403)

    def test_status_change_notifies_client(self):
        self.post(self.m, f"/orders/{self.oid}/status", status="repair")
        self.assertEqual(self.q("SELECT status_id FROM orders WHERE id=?", (self.oid,))[0]["status_id"], 3)
        notes = self.q("SELECT message FROM notifications WHERE user_id=?", (self.user_id("c1@t.ru"),))
        self.assertTrue(any("В ремонте" in n["message"] for n in notes))
        self.assertIn("В ремонте", self.client("c1@t.ru").get("/notifications").get_data(as_text=True))

    def test_invalid_status_rejected(self):
        self.post(self.m, f"/orders/{self.oid}/status", status="hacked")
        self.assertEqual(self.q("SELECT status_id FROM orders WHERE id=?", (self.oid,))[0]["status_id"], 2)

    def test_issued_order_locked_for_master(self):
        self.post(self.m, f"/orders/{self.oid}/status", status="issued")
        self.assertIsNotNone(self.q("SELECT closed_at FROM orders WHERE id=?", (self.oid,))[0]["closed_at"])
        self.post(self.m, f"/orders/{self.oid}/status", status="repair")
        self.assertEqual(self.q("SELECT status_id FROM orders WHERE id=?", (self.oid,))[0]["status_id"], 5)
        self.post(self.a, f"/orders/{self.oid}/status", status="repair")   # админ может вернуть
        row = self.q("SELECT status_id, closed_at FROM orders WHERE id=?", (self.oid,))[0]
        self.assertEqual(row["status_id"], 3)
        self.assertIsNone(row["closed_at"])

    def stock(self):
        return self.q("SELECT quantity FROM parts WHERE id=1")[0]["quantity"]

    def test_parts_stock_flow(self):
        self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity="2")
        self.assertEqual(self.stock(), 3)
        op = self.q("SELECT * FROM order_parts")[0]
        self.assertEqual((op["quantity"], op["unit_price"]), (2, 900))
        self.post(self.m, f"/orders/{self.oid}/parts/{op['id']}/delete")
        self.assertEqual(self.stock(), 5)
        self.assertEqual(len(self.q("SELECT * FROM order_parts")), 0)

    def test_parts_boundaries(self):
        self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity="5")   # ровно весь остаток
        self.assertEqual(self.stock(), 0)
        self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity="1")   # больше нет
        self.assertEqual(self.stock(), 0)
        self.assertEqual(len(self.q("SELECT * FROM order_parts")), 1)

    def test_parts_invalid_values(self):
        for bad in ("0", "-1", "abc", "", "1001", "2.5"):
            self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity=bad)
        self.post(self.m, f"/orders/{self.oid}/parts", part_id="999", quantity="1")
        self.assertEqual(self.stock(), 5)
        self.assertEqual(len(self.q("SELECT * FROM order_parts")), 0)

    def test_over_stock_does_not_go_negative(self):
        self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity="6")
        self.assertEqual(self.stock(), 5)

    def test_labor_cost_boundaries(self):
        for ok, val in (("0", 0), ("10000000", 10_000_000), ("1500,50", 1500.5)):
            self.post(self.m, f"/orders/{self.oid}/labor", labor_cost=ok)
            self.assertEqual(self.q("SELECT labor_cost FROM orders WHERE id=?", (self.oid,))[0]["labor_cost"], val)
        for bad in ("-1", "10000001", "abc", "nan", "inf", ""):
            self.post(self.m, f"/orders/{self.oid}/labor", labor_cost=bad)
        self.assertEqual(self.q("SELECT labor_cost FROM orders WHERE id=?", (self.oid,))[0]["labor_cost"], 1500.5)

    def test_total_in_page(self):
        self.post(self.m, f"/orders/{self.oid}/labor", labor_cost="1000")
        self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity="2")
        html = self.client("c1@t.ru").get(f"/orders/{self.oid}").get_data(as_text=True)
        self.assertIn("2 800 ₽", html)   # 1000 + 2*900


class AdminTests(Base):
    def setUp(self):
        super().setUp()
        self.a = self.client("admin@t.ru")

    def test_kanban_api(self):
        oid = self.new_order_id()
        r = self.a.post(f"/admin/api/orders/{oid}/status", json={"status": "repair"}, headers={"X-CSRF-Token": "tok"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.q("SELECT status_id FROM orders WHERE id=?", (oid,))[0]["status_id"], 3)
        bad = self.a.post(f"/admin/api/orders/{oid}/status", json={"status": "zzz"}, headers={"X-CSRF-Token": "tok"})
        self.assertEqual(bad.status_code, 400)
        no_csrf = self.a.post(f"/admin/api/orders/{oid}/status", json={"status": "ready"})
        self.assertEqual(no_csrf.status_code, 400)
        self.assertEqual(self.a.post("/admin/api/orders/9999/status", json={"status": "ready"},
                                     headers={"X-CSRF-Token": "tok"}).status_code, 404)

    def test_kanban_page(self):
        self.new_order_id()
        self.assertEqual(self.a.get("/admin/kanban").status_code, 200)

    def test_service_crud_and_validation(self):
        ok = dict(name="Замена стекла", description="", device_type_id="1", price_from="1000",
                  price_to="2000", duration_days="2", is_active="1")
        self.assertEqual(self.post(self.a, "/admin/services/new", **ok).status_code, 200)
        self.assertEqual(len(self.q("SELECT * FROM services")), 1)
        for bad in (dict(price_to="500"), dict(price_from="-1"), dict(name="A"), dict(duration_days="0"),
                    dict(price_from="abc"), dict(device_type_id="999")):
            r = self.a.post("/admin/services/new", data={**ok, **bad, "csrf_token": "tok"})
            self.assertEqual(r.status_code, 400, bad)
        self.assertEqual(len(self.q("SELECT * FROM services")), 1)
        self.post(self.a, "/admin/services/1/edit", **{**ok, "name": "Новое имя"})
        self.assertEqual(self.q("SELECT name FROM services")[0]["name"], "Новое имя")
        self.post(self.a, "/admin/services/1/edit", **{k: v for k, v in ok.items() if k != "is_active"})
        self.assertEqual(self.q("SELECT is_active FROM services")[0]["is_active"], 0)
        self.post(self.a, "/admin/services/1/delete")
        self.assertEqual(len(self.q("SELECT * FROM services")), 0)

    def test_user_management(self):
        r = self.post(self.a, "/admin/users/new", full_name="Новый Мастер", email="nm@t.ru",
                      phone="", role="master", is_active="1", password="Master123")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.q("SELECT role FROM users WHERE email='nm@t.ru'")[0]["role"], "master")
        r = self.a.post("/admin/users/new", data=dict(full_name="X Y", email="bad", role="master",
                        password="Master123", csrf_token="tok"))
        self.assertEqual(r.status_code, 400)
        r = self.a.post("/admin/users/new", data=dict(full_name="X Y", email="q@t.ru", role="root",
                        password="Master123", csrf_token="tok"))
        self.assertEqual(r.status_code, 400)

    def test_admin_cannot_demote_self(self):
        aid = self.user_id("admin@t.ru")
        r = self.a.post(f"/admin/users/{aid}/edit", data=dict(full_name="Админ Тестов", email="admin@t.ru",
                        role="client", is_active="1", csrf_token="tok"))
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.q("SELECT role FROM users WHERE id=?", (aid,))[0]["role"], "admin")

    def test_parts_admin(self):
        ok = dict(name="Экран", sku="S-1", quantity="0", min_quantity="0", unit_price="0")
        self.assertEqual(self.post(self.a, "/admin/parts/new", **ok).status_code, 200)   # границы: 0
        self.assertEqual(self.a.post("/admin/parts/new", data={**ok, "csrf_token": "tok"}).status_code, 400)  # дубль SKU
        self.assertEqual(self.a.post("/admin/parts/new", data={**ok, "sku": "S-2", "quantity": "-1", "csrf_token": "tok"}).status_code, 400)
        self.post(self.a, "/admin/parts/1/restock", quantity="10")
        self.assertEqual(self.q("SELECT quantity FROM parts WHERE id=1")[0]["quantity"], 15)
        self.post(self.a, "/admin/parts/1/restock", quantity="0")
        self.assertEqual(self.q("SELECT quantity FROM parts WHERE id=1")[0]["quantity"], 15)

    def test_cannot_delete_used_part(self):
        oid = self.new_order_id()
        self.post(self.a, f"/orders/{oid}/parts", part_id="1", quantity="1")
        r = self.post(self.a, "/admin/parts/1/delete")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(self.q("SELECT * FROM parts WHERE id=1")), 1)

    def test_orders_filters(self):
        oid = self.new_order_id()
        for url in ("/admin/orders", "/admin/orders?status=accepted", "/admin/orders?master=none",
                    f"/admin/orders?q={oid}", "/admin/orders?q=iPhone", "/admin/orders?q=' OR 1=1 --"):
            self.assertEqual(self.a.get(url).status_code, 200, url)

    def test_stats_api(self):
        oid = self.new_order_id()
        self.post(self.a, f"/orders/{oid}/labor", labor_cost="2000")
        self.post(self.a, f"/orders/{oid}/status", status="issued")
        for p, n in (("month", 12), ("day", 30)):
            d = self.a.get(f"/admin/api/stats?period={p}").get_json()
            self.assertEqual(len(d["labels"]), n)
            self.assertEqual(sum(d["orders"]), 1)
            self.assertEqual(sum(d["revenue"]), 2000)
        self.assertEqual(self.a.get("/admin/stats").status_code, 200)
        self.assertEqual(self.client("c1@t.ru").get("/admin/api/stats").status_code, 403)


class DatabaseConstraintTests(Base):
    def test_check_constraints(self):
        import sqlite3
        with self.app.app_context():
            c = db.get_db()
            for sql in ("INSERT INTO parts (name, sku, quantity, unit_price) VALUES ('Aa','X',-1,1)",
                        "INSERT INTO users (email,password_hash,full_name,role) VALUES ('z@z.ru','h','Zz','boss')",
                        "INSERT INTO services (name,price_from,price_to) VALUES ('Aa',10,5)",
                        "INSERT INTO orders (public_token,client_id,device_type_id,fault_type_id,device_model,description) "
                        "VALUES ('t',999,1,1,'Model','long enough description')"):
                with self.assertRaises(sqlite3.IntegrityError, msg=sql):
                    c.execute(sql)


if __name__ == "__main__":
    unittest.main()
