"""Автотесты приложения «Ремонтная мастерская».

Запуск (с понятным выводом):  py run_tests.py
"""
import io
import os
import tempfile
import unittest

from PIL import Image
from werkzeug.security import generate_password_hash

from shop import create_app, db, security

# быстрый хеш только для тестов (в приложении используется стандартный, стойкий)
TEST_HASH = generate_password_hash("Passw0rd!", method="pbkdf2:sha256:1000")


def png_bytes():
    buf = io.BytesIO()
    Image.new("RGB", (8, 8), "red").save(buf, "PNG")
    buf.seek(0)
    return buf


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app({
            "TESTING": True,
            "DATABASE": os.path.join(self.tmp.name, "t.db"),
            "UPLOAD_FOLDER": os.path.join(self.tmp.name, "up"),
        })
        security._failed_logins.clear()
        with self.app.app_context():
            db.init_db()
            c = db.get_db()
            c.execute("INSERT INTO device_types (name) VALUES ('Смартфон')")
            c.execute("INSERT INTO fault_types (name) VALUES ('Не включается')")
            c.execute("INSERT INTO parts (name, sku, quantity, min_quantity, unit_price) "
                      "VALUES ('Аккумулятор', 'B-1', 5, 1, 900)")
            for email, name, role in [("admin@t.ru", "Админ Тестов", "admin"),
                                      ("m1@t.ru", "Мастер Один", "master"),
                                      ("m2@t.ru", "Мастер Два", "master"),
                                      ("c1@t.ru", "Клиент Один", "client"),
                                      ("c2@t.ru", "Клиент Два", "client")]:
                c.execute("INSERT INTO users (email, password_hash, full_name, phone, role) VALUES (?,?,?,?,?)",
                          (email, TEST_HASH, name, "+7 900 111-22-33", role))
            c.commit()

    def tearDown(self):
        self.tmp.cleanup()

    def client(self, email=None):
        cl = self.app.test_client()
        with cl.session_transaction() as s:
            s["_csrf"] = "tok"
        if email:
            r = cl.post("/login", data={"email": email, "password": "Passw0rd!", "csrf_token": "tok"})
            self.assertEqual(r.status_code, 302, f"вход {email} не удался")
            with cl.session_transaction() as s:   # вход очищает сессию (защита от фиксации)
                s["_csrf"] = "tok"
        return cl

    def post(self, cl, url, **data):
        data["csrf_token"] = "tok"
        return cl.post(url, data=data, follow_redirects=True)

    def q(self, sql, args=()):
        with self.app.app_context():
            return [dict(r) for r in db.query(sql, args)]

    def make_order(self, cl, **over):
        data = dict(device_type_id="1", fault_type_id="1", device_model="iPhone 12",
                    description="Не включается после падения", csrf_token="tok")
        data.update(over)
        return cl.post("/orders/new", data=data)

    def new_order_id(self, email="c1@t.ru"):
        r = self.make_order(self.client(email))
        self.assertEqual(r.status_code, 302)
        return self.q("SELECT MAX(id) i FROM orders")[0]["i"]

    def user_id(self, email):
        return self.q("SELECT id FROM users WHERE email=?", (email,))[0]["id"]

    def photo_form(self, files):
        return dict(device_type_id="1", fault_type_id="1", device_model="Pixel 7",
                    description="Разбит экран, нужна замена", csrf_token="tok", photos=files)


class T1_Auth(Base):
    """1. Регистрация и вход"""

    def test_register_ok(self):
        """Регистрация: клиент создаётся, пароль хранится в виде хеша, выбрать роль «админ» нельзя"""
        d = dict(full_name="Новый Клиент", email="new@t.ru", phone="+7 900 555-66-77",
                 password="Abcdef12", password2="Abcdef12", csrf_token="tok", role="admin")
        self.assertEqual(self.client().post("/register", data=d).status_code, 302)
        u = self.q("SELECT role, password_hash FROM users WHERE email='new@t.ru'")[0]
        self.assertEqual(u["role"], "client")
        self.assertNotIn("Abcdef12", u["password_hash"])

    def test_register_validation(self):
        """Регистрация: отклоняются плохой e-mail, короткий пароль, пароль без цифр, разные пароли, чужой e-mail"""
        base = dict(full_name="Новый Клиент", email="new@t.ru", phone="+7 900 555-66-77",
                    password="Abcdef12", password2="Abcdef12", csrf_token="tok")
        for bad in (dict(email="no-at"), dict(password="short1", password2="short1"),
                    dict(password="onlyletters", password2="onlyletters"),
                    dict(password2="Different1"), dict(phone="abc"), dict(email="c1@t.ru")):
            r = self.client().post("/register", data={**base, **bad})
            self.assertEqual(r.status_code, 400, bad)

    def test_login_rules(self):
        """Вход: неверный пароль и отключённый пользователь не пускаются"""
        cl = self.client()
        r = cl.post("/login", data={"email": "c1@t.ru", "password": "bad", "csrf_token": "tok"})
        self.assertEqual(r.status_code, 401)
        with self.app.app_context():
            db.execute("UPDATE users SET is_active=0 WHERE email='c1@t.ru'")
            db.commit()
        r = cl.post("/login", data={"email": "c1@t.ru", "password": "Passw0rd!", "csrf_token": "tok"})
        self.assertEqual(r.status_code, 401)

    def test_login_rate_limit(self):
        """Защита от подбора пароля: после 5 неудачных попыток вход блокируется"""
        cl = self.client()
        for _ in range(5):
            cl.post("/login", data={"email": "c1@t.ru", "password": "bad", "csrf_token": "tok"})
        r = cl.post("/login", data={"email": "c1@t.ru", "password": "Passw0rd!", "csrf_token": "tok"})
        self.assertEqual(r.status_code, 429)

    def test_csrf(self):
        """Защита форм: запрос без секретного токена (CSRF) отклоняется"""
        r = self.app.test_client().post("/login", data={"email": "c1@t.ru", "password": "Passw0rd!"})
        self.assertEqual(r.status_code, 400)


class T2_Access(Base):
    """2. Права доступа"""

    def test_roles(self):
        """Гость уходит на вход, а клиент и мастер не могут открыть чужие разделы (ошибка 403)"""
        for url in ("/cabinet", "/admin/", "/master", "/orders/new"):
            self.assertEqual(self.client().get(url).status_code, 302, url)
        c, m = self.client("c1@t.ru"), self.client("m1@t.ru")
        self.assertEqual(c.get("/admin/").status_code, 403)
        self.assertEqual(c.get("/master").status_code, 403)
        self.assertEqual(m.get("/admin/orders").status_code, 403)
        self.assertEqual(self.client("admin@t.ru").get("/admin/").status_code, 200)

    def test_sql_injection(self):
        """Защита от SQL-инъекций: вредный текст в поиске не ломает и не удаляет данные"""
        r = self.client().get("/services?q=' OR 1=1; DROP TABLE users; --")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(self.q("SELECT * FROM users")), 5)

    def test_client_isolation(self):
        """Клиент видит только свои заявки, фото и PDF; чужие недоступны"""
        cl = self.client("c1@t.ru")
        cl.post("/orders/new", content_type="multipart/form-data",
                data=self.photo_form((png_bytes(), "a.png")))
        oid = self.q("SELECT MAX(id) i FROM orders")[0]["i"]
        other = self.client("c2@t.ru")
        self.assertEqual(cl.get(f"/orders/{oid}").status_code, 200)
        self.assertEqual(other.get(f"/orders/{oid}").status_code, 403)
        self.assertEqual(other.get(f"/orders/{oid}/receipt.pdf").status_code, 403)
        self.assertEqual(cl.get("/photos/1").status_code, 200)
        self.assertEqual(other.get("/photos/1").status_code, 403)
        self.assertEqual(other.post(f"/orders/{oid}/comment", data={"body": "x", "csrf_token": "tok"}).status_code, 403)


class T3_ClientOrders(Base):
    """3. Заявки клиента"""

    def test_create_and_boundaries(self):
        """Создание заявки: статус «Принята», запись в историю; описание принимается ровно от 10 до 2000 символов"""
        oid = self.new_order_id()
        self.assertEqual(self.q("SELECT status_id FROM orders WHERE id=?", (oid,))[0]["status_id"], 1)
        self.assertEqual(len(self.q("SELECT * FROM status_history WHERE order_id=?", (oid,))), 1)
        cl = self.client("c1@t.ru")
        for bad in (dict(description="x" * 9), dict(description="x" * 2001), dict(device_model="A"),
                    dict(device_type_id="999"), dict(fault_type_id="abc")):
            self.assertEqual(self.make_order(cl, **bad).status_code, 400, bad)
        self.assertEqual(self.make_order(cl, description="x" * 10).status_code, 302)
        self.assertEqual(self.make_order(cl, description="x" * 2000).status_code, 302)

    def test_photos(self):
        """Фото: настоящая картинка загружается, поддельный файл и больше 3 фото отклоняются"""
        cl = self.client("c1@t.ru")
        mp = "multipart/form-data"
        self.assertEqual(cl.post("/orders/new", content_type=mp, data=self.photo_form((png_bytes(), "a.png"))).status_code, 302)
        self.assertEqual(len(self.q("SELECT * FROM order_photos")), 1)
        fake = self.photo_form((io.BytesIO(b"<?php evil ?>"), "shell.png"))
        self.assertEqual(cl.post("/orders/new", content_type=mp, data=fake).status_code, 400)
        four = self.photo_form([(png_bytes(), f"{i}.png") for i in range(4)])
        self.assertEqual(cl.post("/orders/new", content_type=mp, data=four).status_code, 400)
        self.assertEqual(len(self.q("SELECT * FROM orders")), 1)

    def test_pdf_and_public_page(self):
        """PDF-квитанция создаётся; публичная страница по QR показывает статус, но не личные данные"""
        oid = self.new_order_id()
        r = self.client("c1@t.ru").get(f"/orders/{oid}/receipt.pdf")
        self.assertTrue(r.data.startswith(b"%PDF"))
        token = self.q("SELECT public_token FROM orders WHERE id=?", (oid,))[0]["public_token"]
        html = self.client().get(f"/track/{token}").get_data(as_text=True)
        self.assertIn("Принята", html)
        self.assertNotIn("c1@t.ru", html)
        self.assertNotIn("Клиент Один", html)
        self.assertEqual(self.client().get("/track/unknown").status_code, 404)


class T4_MasterAndStock(Base):
    """4. Мастер, статусы и склад"""

    def setUp(self):
        super().setUp()
        self.oid = self.new_order_id()
        self.a = self.client("admin@t.ru")
        self.post(self.a, f"/orders/{self.oid}/assign", master_id=str(self.user_id("m1@t.ru")))
        self.m = self.client("m1@t.ru")

    def status(self):
        return self.q("SELECT status_id FROM orders WHERE id=?", (self.oid,))[0]["status_id"]

    def stock(self):
        return self.q("SELECT quantity FROM parts WHERE id=1")[0]["quantity"]

    def test_assign(self):
        """Назначение мастера: заявка уходит в «В диагностике», её видит только этот мастер"""
        self.assertEqual(self.status(), 2)
        self.assertIn(f"#{self.oid}", self.m.get("/master").get_data(as_text=True))
        m2 = self.client("m2@t.ru")
        self.assertNotIn(f"#{self.oid}", m2.get("/master").get_data(as_text=True))
        self.assertEqual(m2.get(f"/orders/{self.oid}").status_code, 403)

    def test_status_change(self):
        """Смена статуса: клиент получает уведомление; неверный статус и смена от клиента не проходят"""
        self.post(self.m, f"/orders/{self.oid}/status", status="repair")
        self.assertEqual(self.status(), 3)
        page = self.client("c1@t.ru").get("/notifications").get_data(as_text=True)
        self.assertIn("В ремонте", page)
        self.post(self.m, f"/orders/{self.oid}/status", status="hacked")
        self.assertEqual(self.status(), 3)
        c = self.client("c1@t.ru")
        self.assertEqual(c.post(f"/orders/{self.oid}/status", data={"status": "issued", "csrf_token": "tok"}).status_code, 403)

    def test_issued_locked(self):
        """Выданная заявка: мастер её уже не меняет, администратор может вернуть в работу"""
        self.post(self.m, f"/orders/{self.oid}/status", status="issued")
        self.assertEqual(self.status(), 5)
        self.post(self.m, f"/orders/{self.oid}/status", status="repair")
        self.assertEqual(self.status(), 5)
        self.post(self.a, f"/orders/{self.oid}/status", status="repair")
        self.assertEqual(self.status(), 3)

    def test_parts(self):
        """Запчасти: остаток уменьшается и возвращается; нельзя списать больше остатка и неверное количество"""
        self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity="2")
        self.assertEqual(self.stock(), 3)
        op = self.q("SELECT id FROM order_parts")[0]["id"]
        self.post(self.m, f"/orders/{self.oid}/parts/{op}/delete")
        self.assertEqual(self.stock(), 5)
        for bad in ("6", "0", "-1", "abc", "2.5", "1001"):
            self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity=bad)
        self.assertEqual(self.stock(), 5)
        self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity="5")   # ровно весь остаток
        self.assertEqual(self.stock(), 0)

    def test_labor_and_total(self):
        """Стоимость: работы принимаются от 0 до 10 000 000, итог = работы + запчасти"""
        for bad in ("-1", "10000001", "abc", "nan", ""):
            self.post(self.m, f"/orders/{self.oid}/labor", labor_cost=bad)
        self.assertEqual(self.q("SELECT labor_cost FROM orders WHERE id=?", (self.oid,))[0]["labor_cost"], 0)
        self.post(self.m, f"/orders/{self.oid}/labor", labor_cost="10000000")
        self.assertEqual(self.q("SELECT labor_cost FROM orders WHERE id=?", (self.oid,))[0]["labor_cost"], 10_000_000)
        self.post(self.m, f"/orders/{self.oid}/labor", labor_cost="1000")
        self.post(self.m, f"/orders/{self.oid}/parts", part_id="1", quantity="2")
        html = self.client("c1@t.ru").get(f"/orders/{self.oid}").get_data(as_text=True)
        self.assertIn("2 800 ₽", html)   # 1000 + 2 × 900


class T5_Admin(Base):
    """5. Администратор"""

    def setUp(self):
        super().setUp()
        self.a = self.client("admin@t.ru")

    def test_kanban(self):
        """Канбан: статус меняется перетаскиванием; неверный статус, заявка-призрак и запрос без токена отклоняются"""
        oid = self.new_order_id()
        h = {"X-CSRF-Token": "tok"}
        url = f"/admin/api/orders/{oid}/status"
        self.assertEqual(self.a.post(url, json={"status": "repair"}, headers=h).status_code, 200)
        self.assertEqual(self.q("SELECT status_id FROM orders WHERE id=?", (oid,))[0]["status_id"], 3)
        self.assertEqual(self.a.post(url, json={"status": "zzz"}, headers=h).status_code, 400)
        self.assertEqual(self.a.post(url, json={"status": "ready"}).status_code, 400)
        self.assertEqual(self.a.post("/admin/api/orders/9999/status", json={"status": "ready"}, headers=h).status_code, 404)

    def test_services(self):
        """Услуги: добавление, изменение, удаление; цена «до» меньше «от» и отрицательная цена отклоняются"""
        ok = dict(name="Замена стекла", description="", device_type_id="1", price_from="1000",
                  price_to="2000", duration_days="2", is_active="1")
        self.post(self.a, "/admin/services/new", **ok)
        self.assertEqual(len(self.q("SELECT * FROM services")), 1)
        for bad in (dict(price_to="500"), dict(price_from="-1"), dict(name="A"), dict(duration_days="0")):
            self.assertEqual(self.a.post("/admin/services/new", data={**ok, **bad, "csrf_token": "tok"}).status_code, 400, bad)
        self.post(self.a, "/admin/services/1/edit", **{**ok, "name": "Новое имя"})
        self.assertEqual(self.q("SELECT name FROM services")[0]["name"], "Новое имя")
        self.post(self.a, "/admin/services/1/delete")
        self.assertEqual(len(self.q("SELECT * FROM services")), 0)

    def test_users_and_parts(self):
        """Люди и склад: создание мастера, запрет разжаловать себя, дубль артикула, пополнение, защита используемой запчасти"""
        self.post(self.a, "/admin/users/new", full_name="Новый Мастер", email="nm@t.ru", phone="",
                  role="master", is_active="1", password="Master123")
        self.assertEqual(self.q("SELECT role FROM users WHERE email='nm@t.ru'")[0]["role"], "master")
        aid = self.user_id("admin@t.ru")
        r = self.a.post(f"/admin/users/{aid}/edit", data=dict(full_name="Админ Тестов", email="admin@t.ru",
                        role="client", is_active="1", csrf_token="tok"))
        self.assertEqual(r.status_code, 400)
        part = dict(name="Экран", sku="B-1", quantity="1", min_quantity="0", unit_price="5")
        self.assertEqual(self.a.post("/admin/parts/new", data={**part, "csrf_token": "tok"}).status_code, 400)  # дубль
        self.post(self.a, "/admin/parts/1/restock", quantity="10")
        self.assertEqual(self.q("SELECT quantity FROM parts WHERE id=1")[0]["quantity"], 15)
        oid = self.new_order_id()
        self.post(self.a, f"/orders/{oid}/parts", part_id="1", quantity="1")
        self.post(self.a, "/admin/parts/1/delete")
        self.assertEqual(len(self.q("SELECT * FROM parts WHERE id=1")), 1)

    def test_stats(self):
        """Статистика: выручка и число заявок считаются верно, фильтры заявок работают"""
        oid = self.new_order_id()
        self.post(self.a, f"/orders/{oid}/labor", labor_cost="2000")
        self.post(self.a, f"/orders/{oid}/status", status="issued")
        for p, n in (("month", 12), ("day", 30)):
            d = self.a.get(f"/admin/api/stats?period={p}").get_json()
            self.assertEqual((len(d["labels"]), sum(d["orders"]), sum(d["revenue"])), (n, 1, 2000))
        for url in ("/admin/orders?status=accepted", "/admin/orders?q=iPhone", "/admin/orders?q=' OR 1=1 --"):
            self.assertEqual(self.a.get(url).status_code, 200, url)


class T6_Database(Base):
    """6. База данных"""

    def test_constraints(self):
        """Ограничения БД: база сама не даёт сохранить отрицательный остаток, неверную роль, неверную цену, несуществующего клиента"""
        import sqlite3
        with self.app.app_context():
            c = db.get_db()
            for sql in ("INSERT INTO parts (name, sku, quantity, unit_price) VALUES ('Aa','X',-1,1)",
                        "INSERT INTO users (email,password_hash,full_name,role) VALUES ('z@z.ru','h','Zz','boss')",
                        "INSERT INTO services (name,price_from,price_to) VALUES ('Aa',10,5)",
                        "INSERT INTO orders (public_token,client_id,device_type_id,fault_type_id,device_model,description) "
                        "VALUES ('t',999,1,1,'Model','long enough description')"):
                with self.assertRaises(sqlite3.IntegrityError, msg=sql):
                    c.execute(sql)


if __name__ == "__main__":
    unittest.main()
