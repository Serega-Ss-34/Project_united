"""Запуск тестов с понятным выводом: что именно проверяется в каждом тесте."""
import sys
import time
import unittest

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(errors="replace")


class Result(unittest.TestResult):
    def __init__(self):
        super().__init__()
        self.group = None
        self.n = 0

    def _head(self, test):
        g = type(test).__doc__
        if g != self.group:
            self.group = g
            print(f"\n{g.strip()}")

    def _line(self, test, mark):
        self._head(test)
        self.n += 1
        print(f"  [{mark}] {test.shortDescription() or test.id()}")

    def addSuccess(self, test):
        super().addSuccess(test); self._line(test, "OK")

    def addFailure(self, test, err):
        super().addFailure(test, err); self._line(test, "ОШИБКА")

    def addError(self, test, err):
        super().addError(test, err); self._line(test, "ОШИБКА")


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.discover("tests", top_level_dir=".")
    print("Автотесты «Ремонтная мастерская»")
    t = time.time()
    res = Result()
    suite.run(res)
    for test, tb in res.failures + res.errors:
        print(f"\n--- {test.shortDescription() or test.id()} ---\n{tb}")
    ok = res.testsRun - len(res.failures) - len(res.errors)
    print(f"\nИтого: пройдено {ok} из {res.testsRun} за {time.time() - t:.1f} с")
    sys.exit(0 if res.wasSuccessful() else 1)
