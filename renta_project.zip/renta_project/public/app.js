// Клиентская часть (SPA на чистом JavaScript, маршрутизация по hash)
const app = document.getElementById('app');
let token = localStorage.getItem('token');
let me = null;

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => Number(n || 0).toLocaleString('ru-RU', { maximumFractionDigits: 2 }) + ' ₽';
const STATUS = { pending: 'Ожидает', confirmed: 'Забронировано', issued: 'Выдано', returned: 'Возвращено', overdue: 'Просрочено', cancelled: 'Отменено' };
const ROLE = { client: 'Клиент', manager: 'Менеджер', admin: 'Администратор' };
const badge = (s) => `<span class="badge s-${s}">${STATUS[s] || s}</span>`;
const photo = (e) => esc(e.photo || '/img/default');
const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

async function api(url, { method = 'GET', body } = {}) {
  const r = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 401 && token) { token = null; me = null; localStorage.removeItem('token'); renderNav(); }
    throw new Error(d.error || 'Ошибка запроса');
  }
  return d;
}
function toast(msg, err) {
  const t = document.createElement('div');
  t.className = 't' + (err ? ' err' : ''); t.textContent = msg;
  document.getElementById('toast').appendChild(t);
  setTimeout(() => t.remove(), 4000);
}
const guard = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };

// ---------- универсальная форма в диалоге ----------
function askForm(title, fields, vals = {}) {
  return new Promise((resolve) => {
    const d = document.createElement('dialog');
    const input = (f) => {
      const v = vals[f.name] ?? f.value ?? '';
      if (f.type === 'select')
        return `<select name="${f.name}">${f.options.map(([o, l]) => `<option value="${esc(o)}" ${String(v) === String(o) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
      if (f.type === 'textarea') return `<textarea name="${f.name}">${esc(v)}</textarea>`;
      return `<input name="${f.name}" type="${f.type || 'text'}" value="${esc(v)}" ${f.required ? 'required' : ''} ${f.min !== undefined ? `min="${f.min}"` : ''}  ${f.max !== undefined ? `max="${f.max}"` : ''} ${f.step ? `step="${f.step}"` : ''}>`;
    };
    d.innerHTML = `<form><h3>${esc(title)}</h3>${fields.map((f) => `<label>${esc(f.label)}${input(f)}</label>`).join('')}
      <div class="row"><button type="button" class="btn ghost" data-x>Отмена</button><button class="btn">OK</button></div></form>`;
    document.body.appendChild(d);
    let done = false;
    const finish = (v) => { if (done) return; done = true; d.close(); d.remove(); resolve(v); };
    d.querySelector('form').onsubmit = (e) => { e.preventDefault(); finish(Object.fromEntries(new FormData(e.target))); };
    d.querySelector('[data-x]').onclick = () => finish(null);
    d.addEventListener('cancel', () => finish(null));
    d.showModal();
  });
}

// ---------- навигация ----------
function renderNav() {
  const h = location.hash || '#/';
  const l = (href, t) => `<a href="${href}" class="${h === href ? 'on' : ''}">${t}</a>`;
  let html = l('#/', 'Каталог');
  if (me) {
    html += l('#/cabinet', 'Мои аренды');
    if (me.role !== 'client') html += l('#/manager', 'Менеджер');
    if (me.role === 'admin') html += l('#/admin', 'Администратор');
    html += `<a href="#/" id="logout">Выйти (${esc(me.name)})</a>`;
  } else html += l('#/login', 'Вход') + l('#/register', 'Регистрация');
  const nav = document.getElementById('nav');
  nav.innerHTML = html; nav.classList.remove('open');
  const lo = document.getElementById('logout');
  if (lo) lo.onclick = async () => { try { await api('/api/logout', { method: 'POST' }); } catch {} token = null; me = null; localStorage.removeItem('token'); renderNav(); };
}
document.getElementById('burger').onclick = () => document.getElementById('nav').classList.toggle('open');

function need(...roles) {
  if (!me) { location.hash = '#/login'; return false; }
  if (roles.length && !roles.includes(me.role)) { app.innerHTML = '<div class="card">Недостаточно прав для просмотра этой страницы.</div>'; return false; }
  return true;
}

// ---------- каталог ----------
let filters = {};
async function catalog() {
  const cats = await api('/api/categories');
  const tariffs = await api('/api/tariffs');
  app.innerHTML = `<h1>Каталог оборудования</h1>
  <form id="f" class="filters card">
    <label>Поиск<input name="q" placeholder="Название" value="${esc(filters.q || '')}"></label>
    <label>Категория<select name="category"><option value="">Все</option>${cats.map((c) => `<option value="${c.id}" ${filters.category == c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>
    <label>Цена от<input name="min" type="number" min="0" style="width:90px" value="${esc(filters.min || '')}"></label>
    <label>Цена до<input name="max" type="number" min="0" style="width:90px" value="${esc(filters.max || '')}"></label>
    <label>Свободно с<input name="from" type="date" value="${esc(filters.from || '')}"></label>
    <label>по<input name="to" type="date" value="${esc(filters.to || '')}"></label>
    <button class="btn">Найти</button><button type="button" class="btn ghost" id="reset">Сбросить</button>
  </form>
  <div id="list" class="grid"></div>
  <div class="card" style="margin-top:20px"><b>Скидки за длительную аренду:</b> ${tariffs.length ? tariffs.map((t) => `${esc(t.name)} — −${t.discount_percent}% (от ${t.min_days} сут.)`).join('; ') : 'нет'}</div>`;
  const load = async () => {
    const list = document.getElementById('list');
    const qs = new URLSearchParams(Object.entries(filters).filter(([, v]) => v !== '' && v != null)).toString();
    try {
      const items = await api('/api/equipment?' + qs);
      const byDates = filters.from && filters.to;
      list.innerHTML = items.length ? items.map((e) => `<div class="card item"><img src="${photo(e)}" alt="${esc(e.name)}" loading="lazy">
        <div class="b"><span class="muted">${esc(e.category)}</span><h3>${esc(e.name)}</h3>
        <span class="price">${money(e.price_per_day)} <span class="muted">/ сутки</span></span>
        <span class="muted">${byDates ? 'Свободно на даты' : 'Доступно'}: <b>${e.available}</b> шт.</span>
        <a class="btn" style="margin-top:auto;text-align:center" href="#/item/${e.id}${byDates ? `?from=${filters.from}&to=${filters.to}` : ''}">Подробнее</a></div></div>`).join('')
        : '<div class="card">Ничего не найдено</div>';
    } catch (e) { list.innerHTML = `<div class="err-box">${esc(e.message)}</div>`; }
  };
  document.getElementById('f').onsubmit = (e) => { e.preventDefault(); filters = Object.fromEntries(new FormData(e.target)); load(); };
  document.getElementById('reset').onclick = () => { filters = {}; catalog(); };
  load();
}

// ---------- карточка и бронирование ----------
async function item(id, query) {
  const e = await api('/api/equipment/' + id);
  const p = new URLSearchParams(query || '');
  const from = p.get('from') || todayStr();
  app.innerHTML = `<p><a href="#/">Назад в каталог</a></p><div class="two">
    <div><img class="item-img" src="${photo(e)}" alt="${esc(e.name)}"></div>
    <div><span class="muted">${esc(e.category)}</span><h1 style="margin-top:0">${esc(e.name)}</h1>
      <p>${esc(e.description) || ''}</p><p class="price">${money(e.price_per_day)} <span class="muted">/ сутки</span></p>
      <form id="bf" class="form card">
        <label>Дата начала<input type="date" name="date_from" min="${todayStr()}" value="${from}" required></label>
        <label>Дата окончания<input type="date" name="date_to" min="${todayStr()}" value="${p.get('to') || from}" required></label>
        <label>Количество<input type="number" name="qty" min="1" max="100" value="1" required></label>
        <div class="quote" id="q">Выберите даты…</div>
        <button class="btn" id="bb">Забронировать</button>
      </form></div></div>`;
  const f = document.getElementById('bf'), q = document.getElementById('q'), bb = document.getElementById('bb');
  const calc = async () => {
    const v = Object.fromEntries(new FormData(f));
    try {
      const r = await api(`/api/quote?equipment_id=${id}&qty=${encodeURIComponent(v.qty)}&from=${v.date_from}&to=${v.date_to}`);
      const ok = r.available >= Number(v.qty);
      q.innerHTML = `Суток: <b>${r.days}</b>${r.discount ? ` (скидка ${r.discount}%)` : ''}<br>Стоимость: <b>${money(r.total)}</b><br>
        <span style="color:${ok ? 'var(--ok)' : 'var(--err)'}">Доступно на эти даты: ${r.available} шт.</span>`;
      bb.disabled = !ok;
    } catch (err) { q.innerHTML = `<span class="err-box">${esc(err.message)}</span>`; bb.disabled = true; }
  };
  f.oninput = calc; calc();
  f.onsubmit = guard(async (ev) => {
    ev.preventDefault();
    if (!me) { toast('Для бронирования войдите в систему', true); location.hash = '#/login'; return; }
    const v = Object.fromEntries(new FormData(f));
    await api('/api/bookings', { method: 'POST', body: { equipment_id: id, qty: v.qty, date_from: v.date_from, date_to: v.date_to } });
    toast('Бронирование создано, ожидайте подтверждения'); location.hash = '#/cabinet';
  });
}

// ---------- вход / регистрация ----------
function authPage(isReg) {
  app.innerHTML = `<h1>${isReg ? 'Регистрация' : 'Вход'}</h1><form id="af" class="form card">
    ${isReg ? '<label>Имя<input name="name" required minlength="2"></label>' : ''}
    <label>Email<input name="email" type="email" required></label>
    <label>Пароль<input name="password" type="password" required minlength="${isReg ? 6 : 1}"></label>
    <div id="err" class="err-box"></div><button class="btn">${isReg ? 'Зарегистрироваться' : 'Войти'}</button>
    ${isReg ? '' : '<div class="muted">Демо: client@rental.local / client123, manager@rental.local / manager123, admin@rental.local / admin123</div>'}</form>`;
  document.getElementById('af').onsubmit = async (e) => {
    e.preventDefault();
    try {
      const r = await api(isReg ? '/api/register' : '/api/login', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) });
      token = r.token; me = r.user; localStorage.setItem('token', token);
      location.hash = me.role === 'admin' ? '#/admin' : me.role === 'manager' ? '#/manager' : '#/';
    } catch (err) { document.getElementById('err').textContent = err.message; }
  };
}

// ---------- личный кабинет ----------
async function cabinet() {
  if (!need()) return;
  const all = await api('/api/bookings/my');
  const cur = all.filter((b) => ['pending', 'confirmed', 'issued', 'overdue'].includes(b.status));
  const hist = all.filter((b) => !cur.includes(b));
  const table = (rows, cancel) => rows.length ? `<div class="tablewrap"><table><tr><th>№</th><th>Оборудование</th><th>Период</th><th>Сумма</th><th>Статус</th><th></th></tr>
    ${rows.map((b) => `<tr><td>${b.id}</td><td>${esc(b.equipment_name)} × ${b.qty}</td><td>${b.date_from} — ${b.date_to}</td>
    <td>${money(b.total_price)}${b.fine ? `<br><span class="muted" style="color:var(--err)">Штраф: ${money(b.fine)}<br>${esc(b.fine_reason)}</span>` : ''}</td>
    <td>${badge(b.status)}</td><td class="act">${cancel && ['pending', 'confirmed'].includes(b.status) ? `<button class="btn sm danger" data-cancel="${b.id}">Отменить</button>` : ''}</td></tr>`).join('')}</table></div>` : '<p class="muted">Пока пусто</p>';
  app.innerHTML = `<h1>Мои аренды</h1><h2>Текущие бронирования</h2><div class="card">${table(cur, true)}</div><h2>История</h2><div class="card">${table(hist)}</div>`;
  app.onclick = guard(async (e) => {
    const b = e.target.closest('[data-cancel]'); if (!b || !confirm('Отменить бронирование?')) return;
    await api(`/api/bookings/${b.dataset.cancel}/cancel`, { method: 'POST' }); toast('Бронирование отменено'); cabinet();
  });
}

// ---------- рабочее место менеджера ----------
let mgrFilter = 'active';
async function manager() {
  if (!need('manager', 'admin')) return;
  const rows = await api('/api/manager/bookings?status=' + mgrFilter);
  app.innerHTML = `<h1>Рабочее место менеджера</h1><div class="card"><label>Показать: <select id="mf">
    ${[['active', 'Активные'], ['pending', 'Ожидают подтверждения'], ['confirmed', 'К выдаче'], ['issued', 'Выданы'], ['overdue', 'Просрочены'], ['returned', 'Возвращены'], ['cancelled', 'Отменены'], ['all', 'Все']]
      .map(([v, l]) => `<option value="${v}" ${mgrFilter === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label></div>
    <div class="card tablewrap">${rows.length ? `<table><tr><th>№</th><th>Клиент</th><th>Оборудование</th><th>Период</th><th>Сумма</th><th>Статус</th><th></th></tr>
    ${rows.map((b) => `<tr><td>${b.id}</td><td>${esc(b.client_name)}<br><span class="muted">${esc(b.client_email)}</span></td><td>${esc(b.equipment_name)} × ${b.qty}</td>
    <td>${b.date_from} — ${b.date_to}</td><td>${money(b.total_price)}${b.fine ? `<br><span style="color:var(--err)">+${money(b.fine)} штраф</span>` : ''}</td><td>${badge(b.status)}
    ${b.condition_out ? `<br><span class="muted">Выдано: ${esc(b.condition_out)}</span>` : ''}${b.condition_in ? `<br><span class="muted">Принято: ${esc(b.condition_in)}</span>` : ''}</td>
    <td class="act">${b.status === 'pending' ? `<button class="btn sm ok" data-a="confirm" data-id="${b.id}">Подтвердить</button>` : ''}
    ${b.status === 'confirmed' ? `<button class="btn sm" data-a="issue" data-id="${b.id}">Выдать</button>` : ''}
    ${['issued', 'overdue'].includes(b.status) ? `<button class="btn sm" data-a="return" data-id="${b.id}" data-qty="${b.qty}">Принять</button>` : ''}
    ${['pending', 'confirmed'].includes(b.status) ? `<button class="btn sm danger" data-a="cancel" data-id="${b.id}">Отменить</button>` : ''}</td></tr>`).join('')}</table>` : '<p class="muted">Нет записей</p>'}</div>`;
  document.getElementById('mf').onchange = (e) => { mgrFilter = e.target.value; manager(); };
  app.onclick = guard(async (e) => {
    const b = e.target.closest('[data-a]'); if (!b) return;
    const id = b.dataset.id, a = b.dataset.a;
    if (a === 'confirm' || a === 'cancel') {
      if (a === 'cancel' && !confirm('Отменить бронирование?')) return;
      await api(`/api/bookings/${id}/${a}`, { method: 'POST' }); toast('Готово');
    } else if (a === 'issue') {
      const v = await askForm('Выдача оборудования', [{ name: 'condition_out', label: 'Состояние при выдаче', type: 'textarea', value: 'Исправно' }]);
      if (!v) return; await api(`/api/bookings/${id}/issue`, { method: 'POST', body: v }); toast('Оборудование выдано');
    } else {
      const v = await askForm('Приём оборудования', [
        { name: 'condition_in', label: 'Состояние при возврате', type: 'textarea', value: 'Исправно' },
        { name: 'damage_fine', label: 'Штраф за повреждение, ₽', type: 'number', min: 0, step: '0.01', value: 0 },
        { name: 'to_repair', label: `Отправить в ремонт (0–${b.dataset.qty} шт.)`, type: 'number', min: 0, value: 0 }]);
      if (!v) return;
      const r = await api(`/api/bookings/${id}/return`, { method: 'POST', body: v });
      toast(r.fine ? `Принято. Штраф: ${money(r.fine)} (${r.fine_reason})` : 'Принято без штрафов');
    }
    manager();
  });
}

// ---------- графики (SVG) ----------
function bars(labels, values, fmt = (v) => Math.round(v)) {
  if (!labels.length) return '<p class="muted">Нет данных</p>';
  const W = 64, H = 170, max = Math.max(1, ...values);
  return `<svg class="chart" style="max-width:${Math.max(labels.length, 3) * 100}px" viewBox="0 0 ${labels.length * W} ${H + 40}">${labels.map((l, i) => {
    const h = values[i] / max * H, x = i * W;
    return `<rect class="bar" x="${x + 10}" y="${H - h + 16}" width="${W - 20}" height="${h}" rx="4"/>
      <text class="bt" x="${x + W / 2}" y="${H - h + 11}" text-anchor="middle">${fmt(values[i])}</text>
      <text class="bt" x="${x + W / 2}" y="${H + 32}" text-anchor="middle">${esc(l.length > 10 ? l.slice(0, 9) + '…' : l)}</text>`;
  }).join('')}</svg>`;
}

// ---------- панель администратора ----------
let adminTab = 'equipment';
const TABS = [['equipment', 'Каталог'], ['categories', 'Категории'], ['stock', 'Склад'], ['users', 'Пользователи'], ['tariffs', 'Тарифы'], ['stats', 'Статистика']];
async function admin() {
  if (!need('admin')) return;
  app.innerHTML = `<h1>Панель администратора</h1><div class="tabs">${TABS.map(([k, l]) => `<button data-tab="${k}" class="${adminTab === k ? 'on' : ''}">${l}</button>`).join('')}</div><div id="tab"></div>`;
  const box = document.getElementById('tab');
  const cats = await api('/api/categories');
  const catOpts = cats.map((c) => [c.id, c.name]);
  let actions = {};
  const eqFields = (creating) => [
    { name: 'name', label: 'Название', required: true },
    { name: 'category_id', label: 'Категория', type: 'select', options: catOpts },
    { name: 'price_per_day', label: 'Цена за сутки, ₽', type: 'number', min: 0.01, step: '0.01', required: true },
    ...(creating ? [{ name: 'qty_total', label: 'Количество единиц', type: 'number', min: 0, required: true, value: 1 }] : [{ name: 'active', label: 'Статус', type: 'select', options: [[1, 'В прокате'], [0, 'Снято с проката']] }]),
    { name: 'photo', label: 'Фото (URL; пусто — заглушка)' }, { name: 'description', label: 'Описание', type: 'textarea' }];

  if (adminTab === 'equipment') {
    const rows = await api('/api/admin/equipment');
    box.innerHTML = `<div class="card tablewrap"><button class="btn" data-do="eq-add" style="margin-bottom:10px">+ Добавить оборудование</button>
      <table><tr><th>Фото</th><th>Название</th><th>Категория</th><th>Цена</th><th>Всего</th><th>Статус</th><th></th></tr>
      ${rows.map((e) => `<tr><td><img src="${photo(e)}" width="60" style="border-radius:6px"></td><td>${esc(e.name)}</td><td>${esc(e.category)}</td><td>${money(e.price_per_day)}</td>
      <td>${e.working} / ${e.qty_total}</td><td>${e.active ? 'В прокате' : '<span class="muted">Снято</span>'}</td>
      <td class="act"><button class="btn sm ghost" data-do="eq-edit" data-id="${e.id}">Изменить</button><button class="btn sm danger" data-do="eq-del" data-id="${e.id}">Удалить</button></td></tr>`).join('')}</table></div>`;
    actions = {
      'eq-add': async () => { const v = await askForm('Новое оборудование', eqFields(true)); if (v) await api('/api/admin/equipment', { method: 'POST', body: v }); },
      'eq-edit': async (id) => { const e = rows.find((r) => r.id == id); const v = await askForm('Редактирование', eqFields(false), e); if (v) await api('/api/admin/equipment/' + id, { method: 'PUT', body: v }); },
      'eq-del': async (id) => { if (!confirm('Удалить оборудование? Если по нему были аренды, оно будет снято с проката.')) return; const r = await api('/api/admin/equipment/' + id, { method: 'DELETE' }); toast(r.deactivated ? 'Есть история аренд — снято с проката' : 'Удалено'); },
    };
  }
  if (adminTab === 'categories') {
    box.innerHTML = `<div class="card tablewrap"><button class="btn" data-do="c-add" style="margin-bottom:10px">+ Добавить категорию</button><table><tr><th>Название</th><th></th></tr>
      ${cats.map((c) => `<tr><td>${esc(c.name)}</td><td class="act"><button class="btn sm ghost" data-do="c-edit" data-id="${c.id}">Изменить</button><button class="btn sm danger" data-do="c-del" data-id="${c.id}">Удалить</button></td></tr>`).join('')}</table></div>`;
    actions = {
      'c-add': async () => { const v = await askForm('Новая категория', [{ name: 'name', label: 'Название', required: true }]); if (v) await api('/api/admin/categories', { method: 'POST', body: v }); },
      'c-edit': async (id) => { const v = await askForm('Категория', [{ name: 'name', label: 'Название', required: true }], cats.find((c) => c.id == id)); if (v) await api('/api/admin/categories/' + id, { method: 'PUT', body: v }); },
      'c-del': async (id) => { if (confirm('Удалить категорию?')) await api('/api/admin/categories/' + id, { method: 'DELETE' }); },
    };
  }
  if (adminTab === 'stock') {
    const [rows, log] = await Promise.all([api('/api/admin/equipment'), api('/api/admin/stock/log')]);
    const AN = { add: 'Поступление', repair: 'В ремонт', restore: 'Из ремонта', writeoff: 'Списание' };
    box.innerHTML = `<div class="card tablewrap"><table><tr><th>Оборудование</th><th>Всего</th><th>В работе</th><th>В ремонте</th><th>Списано</th><th></th></tr>
      ${rows.map((e) => `<tr><td>${esc(e.name)}</td><td>${e.qty_total}</td><td><b>${e.working}</b></td><td>${e.qty_repair}</td><td>${e.qty_written_off}</td>
      <td class="act">${Object.entries(AN).map(([k, l]) => `<button class="btn sm ghost" data-do="stock" data-act="${k}" data-id="${e.id}">${l}</button>`).join('')}</td></tr>`).join('')}</table></div>
      <h2>Журнал операций</h2><div class="card tablewrap">${log.length ? `<table><tr><th>Дата</th><th>Оборудование</th><th>Операция</th><th>Кол-во</th><th>Кто</th><th>Примечание</th></tr>
      ${log.map((l) => `<tr><td>${esc(l.created_at)}</td><td>${esc(l.equipment_name)}</td><td>${AN[l.action]}</td><td>${l.qty}</td><td>${esc(l.user_name || 'система')}</td><td>${esc(l.note)}</td></tr>`).join('')}</table>` : '<p class="muted">Пусто</p>'}</div>`;
    actions = { stock: async (id, el) => {
      const v = await askForm(AN[el.dataset.act], [{ name: 'qty', label: 'Количество', type: 'number', min: 1, required: true, value: 1 }, { name: 'note', label: 'Примечание' }]);
      if (v) await api('/api/admin/stock', { method: 'POST', body: { ...v, equipment_id: id, action: el.dataset.act } });
    } };
  }
  if (adminTab === 'users') {
    const rows = await api('/api/admin/users');
    box.innerHTML = `<div class="card tablewrap"><button class="btn" data-do="u-add" style="margin-bottom:10px">+ Добавить сотрудника / пользователя</button>
      <table><tr><th>Имя</th><th>Email</th><th>Роль</th><th></th></tr>${rows.map((u) => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${ROLE[u.role]}</td>
      <td class="act"><button class="btn sm ghost" data-do="u-role" data-id="${u.id}">Роль</button>${u.id === me.id ? '' : `<button class="btn sm danger" data-do="u-del" data-id="${u.id}">Удалить</button>`}</td></tr>`).join('')}</table></div>`;
    const roleOpts = Object.entries(ROLE);
    actions = {
      'u-add': async () => { const v = await askForm('Новый пользователь', [{ name: 'name', label: 'Имя', required: true }, { name: 'email', label: 'Email', type: 'email', required: true }, { name: 'password', label: 'Пароль (от 6 символов)', type: 'password', required: true }, { name: 'role', label: 'Роль', type: 'select', options: roleOpts, value: 'manager' }]); if (v) await api('/api/admin/users', { method: 'POST', body: v }); },
      'u-role': async (id) => { const v = await askForm('Изменить роль', [{ name: 'role', label: 'Роль', type: 'select', options: roleOpts }], rows.find((u) => u.id == id)); if (v) await api('/api/admin/users/' + id, { method: 'PUT', body: v }); },
      'u-del': async (id) => { if (confirm('Удалить пользователя?')) await api('/api/admin/users/' + id, { method: 'DELETE' }); },
    };
  }
  if (adminTab === 'tariffs') {
    const [rows, st] = await Promise.all([api('/api/tariffs'), api('/api/admin/settings')]);
    box.innerHTML = `<div class="card tablewrap"><button class="btn" data-do="t-add" style="margin-bottom:10px">+ Добавить тариф</button>
      <table><tr><th>Название</th><th>От (суток)</th><th>Скидка</th><th></th></tr>${rows.map((t) => `<tr><td>${esc(t.name)}</td><td>${t.min_days}</td><td>${t.discount_percent}%</td>
      <td class="act"><button class="btn sm ghost" data-do="t-edit" data-id="${t.id}">Изменить</button><button class="btn sm danger" data-do="t-del" data-id="${t.id}">Удалить</button></td></tr>`).join('')}</table></div>
      <div class="card">Штраф за просрочку = цена за сутки × кол-во × дни просрочки × коэффициент. Текущий коэффициент: <b>${st.overdue_coef}</b>
      <button class="btn sm ghost" data-do="coef">Изменить</button></div>`;
    const tf = [{ name: 'name', label: 'Название', required: true }, { name: 'min_days', label: 'От скольких суток', type: 'number', min: 2, required: true }, { name: 'discount_percent', label: 'Скидка, %', type: 'number', min: 1, max: 90, step: '0.5', required: true }];
    actions = {
      't-add': async () => { const v = await askForm('Новый тариф', tf); if (v) await api('/api/admin/tariffs', { method: 'POST', body: v }); },
      't-edit': async (id) => { const v = await askForm('Тариф', tf, rows.find((t) => t.id == id)); if (v) await api('/api/admin/tariffs/' + id, { method: 'PUT', body: v }); },
      't-del': async (id) => { if (confirm('Удалить тариф?')) await api('/api/admin/tariffs/' + id, { method: 'DELETE' }); },
      coef: async () => { const v = await askForm('Коэффициент штрафа за просрочку', [{ name: 'overdue_coef', label: 'Коэффициент (1–10)', type: 'number', min: 1, max: 10, step: '0.1', required: true }], st); if (v) await api('/api/admin/settings', { method: 'PUT', body: v }); },
    };
  }
  if (adminTab === 'stats') {
    const s = await api('/api/admin/stats');
    const k = s.summary;
    box.innerHTML = `<div class="kpis"><div class="kpi"><span class="muted">Выручка</span><b>${money(k.revenue)}</b></div><div class="kpi"><span class="muted">Штрафы</span><b>${money(k.fines)}</b></div>
      <div class="kpi"><span class="muted">Сейчас в аренде</span><b>${k.active}</b></div><div class="kpi"><span class="muted">Просрочено</span><b>${k.overdue}</b></div><div class="kpi"><span class="muted">Клиентов</span><b>${k.clients}</b></div></div>
      <div class="charts"><div class="card"><h3>Выручка по месяцам, ₽</h3>${bars(s.months.map((m) => m.m), s.months.map((m) => m.v), (v) => v >= 1000 ? (v / 1000).toFixed(1) + 'k' : Math.round(v))}</div>
      <div class="card"><h3>Бронирования по статусам</h3>${bars(s.byStatus.map((x) => STATUS[x.status]), s.byStatus.map((x) => x.c))}</div>
      <div class="card"><h3>Популярное оборудование (кол-во аренд)</h3>${bars(s.top.map((x) => x.name), s.top.map((x) => x.c))}</div>
      <div class="card"><h3>Выручка по категориям, ₽</h3>${bars(s.byCategory.map((x) => x.name), s.byCategory.map((x) => x.v), (v) => (v / 1000).toFixed(1) + 'k')}</div></div>`;
  }
  app.onclick = guard(async (e) => {
    const t = e.target.closest('[data-tab]');
    if (t) { adminTab = t.dataset.tab; return admin(); }
    const d = e.target.closest('[data-do]'); if (!d) return;
    await actions[d.dataset.do](d.dataset.id, d);
    admin();
  });
}

// ---------- маршрутизатор ----------
async function router() {
  app.onclick = null;
  const [path, query] = (location.hash.slice(1) || '/').split('?');
  const [, page, arg] = path.split('/');
  renderNav();
  try {
    if (!page) await catalog();
    else if (page === 'item') await item(arg, query);
    else if (page === 'login') authPage(false);
    else if (page === 'register') authPage(true);
    else if (page === 'cabinet') await cabinet();
    else if (page === 'manager') await manager();
    else if (page === 'admin') await admin();
    else app.innerHTML = '<div class="card">Страница не найдена</div>';
  } catch (e) { app.innerHTML = `<div class="card err-box">${esc(e.message)}</div>`; }
}
window.addEventListener('hashchange', router);
(async () => {
  if (token) { try { me = await api('/api/me'); } catch { token = null; localStorage.removeItem('token'); } }
  router();
})();
