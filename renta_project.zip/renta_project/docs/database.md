# База данных (SQLite)

## ER-диаграмма (Mermaid)
```mermaid
erDiagram
  users ||--o{ bookings : "оформляет"
  users ||--o{ sessions : "имеет"
  users ||--o{ stock_log : "выполняет"
  categories ||--o{ equipment : "содержит"
  equipment ||--o{ bookings : "бронируется"
  equipment ||--o{ stock_log : "движение"
  users { int id PK
    text name
    text email UK
    text password_hash
    text role "client|manager|admin"
    text created_at }
  sessions { text token PK
    int user_id FK
    text created_at }
  categories { int id PK
    text name UK }
  equipment { int id PK
    int category_id FK
    text name
    text description
    text photo
    real price_per_day
    int qty_total
    int qty_repair
    int qty_written_off
    int active }
  bookings { int id PK
    int user_id FK
    int equipment_id FK
    int qty
    text date_from
    text date_to
    real total_price
    text status
    text condition_out
    text condition_in
    real fine
    text fine_reason
    text created_at
    text issued_at
    text returned_at }
  tariffs { int id PK
    text name
    int min_days UK
    real discount_percent }
  settings { text key PK
    text value }
  stock_log { int id PK
    int equipment_id FK
    int user_id FK
    text action
    int qty
    text note
    text created_at }
```
(Диаграмму можно открыть на mermaid.live или в Markdown-просмотрщике с поддержкой Mermaid.)

## Таблицы
| Таблица | Назначение | Ключевые ограничения |
|---|---|---|
| users | пользователи и сотрудники | email UNIQUE; role IN (client, manager, admin); имя ≥ 2 символов |
| sessions | токены входа | FK → users, ON DELETE CASCADE |
| categories | категории (спорт, туризм, стройка) | name UNIQUE |
| equipment | каталог и складские остатки | price_per_day > 0; qty ≥ 0; qty_repair + qty_written_off ≤ qty_total; FK → categories |
| bookings | бронирования/аренды | qty > 0; date_to ≥ date_from; status IN (pending, confirmed, issued, returned, overdue, cancelled); fine ≥ 0; FK → users, equipment |
| tariffs | скидки за длительную аренду | min_days UNIQUE, ≥ 2; скидка 0–90 % |
| settings | настройки (коэффициент штрафа за просрочку) | key PK |
| stock_log | журнал склада | action IN (add, repair, restore, writeoff); qty > 0 |

Связи: категория 1—N оборудование; пользователь 1—N бронирования; оборудование 1—N бронирования; оборудование 1—N записей журнала.
Индексы: `bookings(equipment_id, date_from, date_to)` — быстрая проверка пересечений; `bookings(user_id)`.
