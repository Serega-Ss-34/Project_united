// HTTP-сервер и REST API (Node.js, без внешних зависимостей)
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { db, today, addDays, diffDays, hashPassword, verifyPassword } = require('./db');

const PUB = path.join(__dirname, 'public');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.ico': 'image/x-icon',
};

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (m) => new HttpError(400, m);
const str = (v) => String(v ?? '').trim();
const int = (v) => (/^-?\d+$/.test(String(v ?? '').trim()) ? Number(v) : NaN);
const num = (v) => (String(v ?? '').trim() !== '' && Number.isFinite(Number(v)) ? Number(v) : NaN);
const round2 = (n) => Math.round(n * 100) / 100;

const routes = [];
function route(method, pattern, roles, handler) {
  routes.push({ method, roles, handler, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$') });
}

// ---------- бизнес-логика ----------
const ACTIVE = "('pending','confirmed','issued','overdue')";
const markOverdue = () => db.prepare("UPDATE bookings SET status='overdue' WHERE status='issued' AND date_to < ?").run(today());
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && addDays(s, 0) === s;
const settingCoef = () => Number(db.prepare("SELECT value FROM settings WHERE key='overdue_coef'").get()?.value ?? 1.5);

function checkDates(from, to, { allowPast = false } = {}) {
  if (!isDate(from) || !isDate(to)) throw bad('Укажите корректные даты (ГГГГ-ММ-ДД)');
  if (to < from) throw bad('Дата окончания раньше даты начала');
  if (!allowPast && from < today()) throw bad('Нельзя бронировать на прошедшую дату');
  if (diffDays(from, to) + 1 > 60) throw bad('Максимальный срок аренды — 60 суток');
}

// Доступное количество на весь период = рабочие единицы − максимальная занятость по дням периода
function availableFor(eqId, from, to, excludeId = 0) {
  const eq = db.prepare('SELECT qty_total - qty_repair - qty_written_off AS w FROM equipment WHERE id=?').get(eqId);
  if (!eq) return 0;
  const rows = db.prepare(`SELECT qty,date_from,date_to,status FROM bookings
    WHERE equipment_id=? AND status IN ${ACTIVE} AND date_from<=? AND (date_to>=? OR status IN ('issued','overdue')) AND id!=?`)
    .all(eqId, to, from, excludeId);
  let maxUsed = 0;
  for (let d = from; d <= to; d = addDays(d, 1)) {
    let used = 0;
    for (const r of rows) {
      const end = (r.status === 'issued' || r.status === 'overdue') && r.date_to < today() ? '9999-12-31' : r.date_to;
      if (r.date_from <= d && end >= d) used += r.qty;
    }
    maxUsed = Math.max(maxUsed, used);
  }
  return Math.max(0, eq.w - maxUsed);
}

function quote(eq, from, to, qty) {
  const days = diffDays(from, to) + 1;
  const t = db.prepare('SELECT MAX(discount_percent) d FROM tariffs WHERE min_days<=?').get(days);
  const discount = t?.d || 0;
  const total = round2(eq.price_per_day * qty * days * (1 - discount / 100));
  return { days, discount, total, available: availableFor(eq.id, from, to) };
}

function getEq(id) {
  const eq = db.prepare(`SELECT e.*, c.name AS category, e.qty_total-e.qty_repair-e.qty_written_off AS working
    FROM equipment e JOIN categories c ON c.id=e.category_id WHERE e.id=?`).get(id);
  if (!eq) throw new HttpError(404, 'Оборудование не найдено');
  return eq;
}

const BOOKING_SQL = `SELECT b.*, e.name AS equipment_name, e.photo, e.price_per_day, u.name AS client_name, u.email AS client_email
  FROM bookings b JOIN equipment e ON e.id=b.equipment_id JOIN users u ON u.id=b.user_id`;
function getBooking(id) {
  const b = db.prepare(BOOKING_SQL + ' WHERE b.id=?').get(id);
  if (!b) throw new HttpError(404, 'Бронирование не найдено');
  return b;
}

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(token,user_id) VALUES(?,?)').run(token, userId);
  return token;
}
const pub = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });

// ---------- аутентификация ----------
route('POST', '/api/register', null, ({ body }) => {
  const name = str(body.name), email = str(body.email).toLowerCase(), pw = String(body.password ?? '');
  if (name.length < 2) throw bad('Имя: минимум 2 символа');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw bad('Некорректный email');
  if (pw.length < 6) throw bad('Пароль: минимум 6 символов');
  const id = Number(db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name, email, hashPassword(pw)).lastInsertRowid);
  return { token: createSession(id), user: { id, name, email, role: 'client' } };
});
route('POST', '/api/login', null, ({ body }) => {
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(str(body.email).toLowerCase());
  if (!u || !verifyPassword(String(body.password ?? ''), u.password_hash)) throw new HttpError(401, 'Неверный email или пароль');
  return { token: createSession(u.id), user: pub(u) };
});
route('POST', '/api/logout', ['client', 'manager', 'admin'], ({ token }) => {
  db.prepare('DELETE FROM sessions WHERE token=?').run(token);
  return { ok: true };
});
route('GET', '/api/me', ['client', 'manager', 'admin'], ({ user }) => pub(user));

// ---------- каталог ----------
route('GET', '/api/categories', null, () => db.prepare('SELECT * FROM categories ORDER BY name').all());
route('GET', '/api/tariffs', null, () => db.prepare('SELECT * FROM tariffs ORDER BY min_days').all());

route('GET', '/api/equipment', null, ({ query }) => {
  const from = str(query.from), to = str(query.to);
  const useDates = from || to;
  if (useDates) {
    if (!isDate(from) || !isDate(to)) throw bad('Укажите обе даты');
    checkDates(from, to, { allowPast: true });
  }
  const where = ['e.active=1'], p = [];
  if (query.category) { where.push('e.category_id=?'); p.push(int(query.category)); }
  if (str(query.min) !== '') { where.push('e.price_per_day>=?'); p.push(num(query.min)); }
  if (str(query.max) !== '') { where.push('e.price_per_day<=?'); p.push(num(query.max)); }
  let rows = db.prepare(`SELECT e.*, c.name AS category, e.qty_total-e.qty_repair-e.qty_written_off AS working
    FROM equipment e JOIN categories c ON c.id=e.category_id WHERE ${where.join(' AND ')} ORDER BY c.name, e.name`).all(...p);
  const q = str(query.q).toLowerCase();
  if (q) rows = rows.filter((e) => (e.name + ' ' + e.description).toLowerCase().includes(q));
  return rows.map((e) => ({ ...e, available: useDates ? availableFor(e.id, from, to) : e.working }));
});
route('GET', '/api/equipment/:id', null, ({ params }) => getEq(int(params.id)));

route('GET', '/api/quote', null, ({ query }) => {
  const eq = getEq(int(query.equipment_id));
  const qty = int(query.qty || 1), from = str(query.from), to = str(query.to);
  if (!(qty >= 1 && qty <= 100)) throw bad('Количество: от 1 до 100');
  checkDates(from, to);
  return quote(eq, from, to, qty);
});

// ---------- бронирования клиента ----------
route('POST', '/api/bookings', ['client', 'manager', 'admin'], ({ user, body }) => {
  const eqId = int(body.equipment_id), qty = int(body.qty), from = str(body.date_from), to = str(body.date_to);
  if (!(qty >= 1 && qty <= 100)) throw bad('Количество: от 1 до 100');
  checkDates(from, to);
  db.exec('BEGIN IMMEDIATE');
  try {
    const eq = getEq(eqId);
    if (!eq.active) throw bad('Оборудование снято с проката');
    const qt = quote(eq, from, to, qty);
    if (qt.available < qty) throw new HttpError(409, `На выбранные даты доступно только ${qt.available} шт.`);
    const id = Number(db.prepare(`INSERT INTO bookings(user_id,equipment_id,qty,date_from,date_to,total_price)
      VALUES(?,?,?,?,?,?)`).run(user.id, eqId, qty, from, to, qt.total).lastInsertRowid);
    db.exec('COMMIT');
    return getBooking(id);
  } catch (e) { db.exec('ROLLBACK'); throw e; }
});
route('GET', '/api/bookings/my', ['client', 'manager', 'admin'], ({ user }) =>
  db.prepare(BOOKING_SQL + ' WHERE b.user_id=? ORDER BY b.id DESC').all(user.id));

route('POST', '/api/bookings/:id/cancel', ['client', 'manager', 'admin'], ({ user, params }) => {
  const b = getBooking(int(params.id));
  if (user.role === 'client' && b.user_id !== user.id) throw new HttpError(403, 'Нет доступа');
  if (!['pending', 'confirmed'].includes(b.status)) throw bad('Отменить можно только бронирование до выдачи');
  db.prepare("UPDATE bookings SET status='cancelled' WHERE id=?").run(b.id);
  return getBooking(b.id);
});

// ---------- рабочее место менеджера ----------
route('GET', '/api/manager/bookings', ['manager', 'admin'], ({ query }) => {
  const st = str(query.status || 'active');
  const where = st === 'all' ? '1=1' : st === 'active' ? `b.status IN ${ACTIVE}` : 'b.status=?';
  const args = ['all', 'active'].includes(st) ? [] : [st];
  return db.prepare(BOOKING_SQL + ` WHERE ${where} ORDER BY b.date_from, b.id`).all(...args);
});
route('POST', '/api/bookings/:id/confirm', ['manager', 'admin'], ({ params }) => {
  const b = getBooking(int(params.id));
  if (b.status !== 'pending') throw bad('Подтвердить можно только бронирование в статусе «Ожидает»');
  db.prepare("UPDATE bookings SET status='confirmed' WHERE id=?").run(b.id);
  return getBooking(b.id);
});
route('POST', '/api/bookings/:id/issue', ['manager', 'admin'], ({ params, body }) => {
  const b = getBooking(int(params.id));
  if (b.status !== 'confirmed') throw bad('Выдать можно только подтверждённое бронирование');
  if (b.date_from > today()) throw bad('Выдача возможна не раньше даты начала аренды (' + b.date_from + ')');
  db.prepare("UPDATE bookings SET status='issued', condition_out=?, issued_at=? WHERE id=?")
    .run(str(body.condition_out) || 'Исправно', today(), b.id);
  return getBooking(b.id);
});
route('POST', '/api/bookings/:id/return', ['manager', 'admin'], ({ params, body }) => {
  const b = getBooking(int(params.id));
  if (!['issued', 'overdue'].includes(b.status)) throw bad('Принять можно только выданное оборудование');
  const damage = body.damage_fine === '' || body.damage_fine == null ? 0 : num(body.damage_fine);
  const toRepair = body.to_repair === '' || body.to_repair == null ? 0 : int(body.to_repair);
  if (!(damage >= 0)) throw bad('Штраф за повреждение: число не меньше 0');
  if (!(toRepair >= 0 && toRepair <= b.qty)) throw bad(`В ремонт можно отправить от 0 до ${b.qty} шт.`);
  const lateDays = Math.max(0, diffDays(b.date_to, today()));
  const lateFine = round2(lateDays * b.price_per_day * b.qty * settingCoef());
  const reasons = [];
  if (lateDays) reasons.push(`Просрочка ${lateDays} дн.: ${lateFine} ₽`);
  if (damage) reasons.push(`Повреждение: ${damage} ₽`);
  db.exec('BEGIN IMMEDIATE');
  try {
    db.prepare(`UPDATE bookings SET status='returned', condition_in=?, fine=?, fine_reason=?, returned_at=? WHERE id=?`)
      .run(str(body.condition_in) || 'Исправно', round2(lateFine + damage), reasons.join('; '), today(), b.id);
    if (toRepair) {
      db.prepare('UPDATE equipment SET qty_repair=qty_repair+? WHERE id=?').run(toRepair, b.equipment_id);
      db.prepare("INSERT INTO stock_log(equipment_id,action,qty,note) VALUES(?,?,?,?)")
        .run(b.equipment_id, 'repair', toRepair, `Возврат по брони №${b.id}`);
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return getBooking(b.id);
});

// ---------- администратор: каталог ----------
function eqInput(body, creating) {
  const d = {
    name: str(body.name), description: str(body.description), photo: str(body.photo),
    category_id: int(body.category_id), price_per_day: num(body.price_per_day),
  };
  if (d.name.length < 2) throw bad('Название: минимум 2 символа');
  if (!db.prepare('SELECT 1 FROM categories WHERE id=?').get(d.category_id)) throw bad('Выберите категорию');
  if (!(d.price_per_day > 0)) throw bad('Цена за сутки должна быть больше 0');
  if (creating) {
    d.qty_total = int(body.qty_total);
    if (!(d.qty_total >= 0)) throw bad('Количество: целое число не меньше 0');
  }
  return d;
}
route('GET', '/api/admin/equipment', ['admin'], () =>
  db.prepare(`SELECT e.*, c.name AS category, e.qty_total-e.qty_repair-e.qty_written_off AS working
    FROM equipment e JOIN categories c ON c.id=e.category_id ORDER BY e.id`).all());
route('POST', '/api/admin/equipment', ['admin'], ({ body }) => {
  const d = eqInput(body, true);
  const id = Number(db.prepare('INSERT INTO equipment(category_id,name,description,photo,price_per_day,qty_total) VALUES(?,?,?,?,?,?)')
    .run(d.category_id, d.name, d.description, d.photo, d.price_per_day, d.qty_total).lastInsertRowid);
  return getEq(id);
});
route('PUT', '/api/admin/equipment/:id', ['admin'], ({ params, body }) => {
  const id = int(params.id); getEq(id);
  const d = eqInput(body, false);
  const active = body.active === 0 || body.active === '0' ? 0 : 1;
  db.prepare('UPDATE equipment SET category_id=?,name=?,description=?,photo=?,price_per_day=?,active=? WHERE id=?')
    .run(d.category_id, d.name, d.description, d.photo, d.price_per_day, active, id);
  return getEq(id);
});
route('DELETE', '/api/admin/equipment/:id', ['admin'], ({ params }) => {
  const id = int(params.id); getEq(id);
  const used = db.prepare('SELECT COUNT(*) c FROM bookings WHERE equipment_id=?').get(id).c;
  if (used) { db.prepare('UPDATE equipment SET active=0 WHERE id=?').run(id); return { ok: true, deactivated: true }; }
  db.prepare('DELETE FROM stock_log WHERE equipment_id=?').run(id);
  db.prepare('DELETE FROM equipment WHERE id=?').run(id);
  return { ok: true };
});

// категории
const catName = (b) => { const n = str(b.name); if (n.length < 2) throw bad('Название: минимум 2 символа'); return n; };
route('POST', '/api/admin/categories', ['admin'], ({ body }) =>
  ({ id: Number(db.prepare('INSERT INTO categories(name) VALUES(?)').run(catName(body)).lastInsertRowid) }));
route('PUT', '/api/admin/categories/:id', ['admin'], ({ params, body }) => {
  db.prepare('UPDATE categories SET name=? WHERE id=?').run(catName(body), int(params.id)); return { ok: true };
});
route('DELETE', '/api/admin/categories/:id', ['admin'], ({ params }) => {
  db.prepare('DELETE FROM categories WHERE id=?').run(int(params.id)); return { ok: true };
});

// тарифы и настройки
function tariffInput(b) {
  const name = str(b.name), min = int(b.min_days), disc = num(b.discount_percent);
  if (!name) throw bad('Укажите название тарифа');
  if (!(min >= 2)) throw bad('Минимум суток: целое число от 2');
  if (!(disc > 0 && disc <= 90)) throw bad('Скидка: от 0 до 90 %');
  return [name, min, disc];
}
route('POST', '/api/admin/tariffs', ['admin'], ({ body }) =>
  ({ id: Number(db.prepare('INSERT INTO tariffs(name,min_days,discount_percent) VALUES(?,?,?)').run(...tariffInput(body)).lastInsertRowid) }));
route('PUT', '/api/admin/tariffs/:id', ['admin'], ({ params, body }) => {
  db.prepare('UPDATE tariffs SET name=?,min_days=?,discount_percent=? WHERE id=?').run(...tariffInput(body), int(params.id)); return { ok: true };
});
route('DELETE', '/api/admin/tariffs/:id', ['admin'], ({ params }) => {
  db.prepare('DELETE FROM tariffs WHERE id=?').run(int(params.id)); return { ok: true };
});
route('GET', '/api/admin/settings', ['admin'], () => ({ overdue_coef: settingCoef() }));
route('PUT', '/api/admin/settings', ['admin'], ({ body }) => {
  const c = num(body.overdue_coef);
  if (!(c >= 1 && c <= 10)) throw bad('Коэффициент штрафа: от 1 до 10');
  db.prepare("INSERT INTO settings(key,value) VALUES('overdue_coef',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(String(c));
  return { overdue_coef: c };
});

// склад
route('POST', '/api/admin/stock', ['admin'], ({ user, body }) => {
  const id = int(body.equipment_id), qty = int(body.qty), action = str(body.action);
  if (!['add', 'repair', 'restore', 'writeoff'].includes(action)) throw bad('Неизвестное действие');
  if (!(qty >= 1 && qty <= 10000)) throw bad('Количество: целое от 1');
  const e = getEq(id);
  let { qty_total: t, qty_repair: r, qty_written_off: w } = e;
  const working = t - r - w;
  if (action === 'add') t += qty;
  if (action === 'repair') { if (qty > working) throw bad(`В работе только ${working} шт.`); r += qty; }
  if (action === 'restore') { if (qty > r) throw bad(`В ремонте только ${r} шт.`); r -= qty; }
  if (action === 'writeoff') {
    const fromRepair = Math.min(r, qty), rest = qty - fromRepair;
    if (rest > working) throw bad('Недостаточно единиц для списания');
    r -= fromRepair; w += qty;
  }
  db.exec('BEGIN IMMEDIATE');
  try {
    db.prepare('UPDATE equipment SET qty_total=?,qty_repair=?,qty_written_off=? WHERE id=?').run(t, r, w, id);
    db.prepare('INSERT INTO stock_log(equipment_id,user_id,action,qty,note) VALUES(?,?,?,?,?)').run(id, user.id, action, qty, str(body.note));
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
  return getEq(id);
});
route('GET', '/api/admin/stock/log', ['admin'], () =>
  db.prepare(`SELECT l.*, e.name AS equipment_name, u.name AS user_name FROM stock_log l
    JOIN equipment e ON e.id=l.equipment_id LEFT JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 30`).all());

// пользователи и сотрудники
route('GET', '/api/admin/users', ['admin'], () =>
  db.prepare('SELECT id,name,email,role,created_at FROM users ORDER BY id').all());
route('POST', '/api/admin/users', ['admin'], ({ body }) => {
  const name = str(body.name), email = str(body.email).toLowerCase(), pw = String(body.password ?? ''), role = str(body.role);
  if (name.length < 2) throw bad('Имя: минимум 2 символа');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw bad('Некорректный email');
  if (pw.length < 6) throw bad('Пароль: минимум 6 символов');
  if (!['client', 'manager', 'admin'].includes(role)) throw bad('Некорректная роль');
  return { id: Number(db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run(name, email, hashPassword(pw), role).lastInsertRowid) };
});
route('PUT', '/api/admin/users/:id', ['admin'], ({ user, params, body }) => {
  const id = int(params.id), role = str(body.role);
  if (!['client', 'manager', 'admin'].includes(role)) throw bad('Некорректная роль');
  if (id === user.id && role !== 'admin') throw bad('Нельзя понизить собственную роль');
  db.prepare('UPDATE users SET role=? WHERE id=?').run(role, id); return { ok: true };
});
route('DELETE', '/api/admin/users/:id', ['admin'], ({ user, params }) => {
  const id = int(params.id);
  if (id === user.id) throw bad('Нельзя удалить самого себя');
  db.prepare('DELETE FROM users WHERE id=?').run(id); return { ok: true };
});

// статистика
route('GET', '/api/admin/stats', ['admin'], () => {
  const money = "total_price + fine";
  const summary = {
    clients: db.prepare("SELECT COUNT(*) c FROM users WHERE role='client'").get().c,
    active: db.prepare("SELECT COUNT(*) c FROM bookings WHERE status IN ('issued','overdue')").get().c,
    overdue: db.prepare("SELECT COUNT(*) c FROM bookings WHERE status='overdue'").get().c,
    revenue: db.prepare(`SELECT COALESCE(SUM(total_price),0) s FROM bookings WHERE status IN ('issued','returned','overdue')`).get().s,
    fines: db.prepare("SELECT COALESCE(SUM(fine),0) s FROM bookings WHERE status='returned'").get().s,
  };
  const months = db.prepare(`SELECT substr(date_from,1,7) m, SUM(${money}) v FROM bookings
    WHERE status IN ('issued','returned','overdue') GROUP BY m ORDER BY m DESC LIMIT 6`).all().reverse();
  const byStatus = db.prepare('SELECT status, COUNT(*) c FROM bookings GROUP BY status').all();
  const top = db.prepare(`SELECT e.name, COUNT(*) c FROM bookings b JOIN equipment e ON e.id=b.equipment_id
    WHERE b.status!='cancelled' GROUP BY e.id ORDER BY c DESC, e.name LIMIT 6`).all();
  const byCategory = db.prepare(`SELECT c.name, SUM(b.total_price) v FROM bookings b JOIN equipment e ON e.id=b.equipment_id
    JOIN categories c ON c.id=e.category_id WHERE b.status IN ('issued','returned','overdue') GROUP BY c.id ORDER BY v DESC`).all();
  return { summary, months, byStatus, top, byCategory };
});

// ---------- HTTP ----------
function send(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 1e6) { reject(bad('Слишком большой запрос')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(bad('Некорректный JSON')); }
    });
  });
}
async function handleApi(req, res, url) {
  markOverdue();
  const match = routes.find((r) => r.method === req.method && r.re.test(url.pathname));
  if (!match) throw new HttpError(404, 'Маршрут не найден');
  const token = (req.headers.authorization || '').replace(/^Bearer /, '');
  const user = token ? db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?').get(token) : null;
  if (match.roles) {
    if (!user) throw new HttpError(401, 'Требуется вход в систему');
    if (!match.roles.includes(user.role)) throw new HttpError(403, 'Недостаточно прав');
  }
  const body = ['POST', 'PUT', 'PATCH'].includes(req.method) ? await readBody(req) : {};
  const params = url.pathname.match(match.re).groups || {};
  send(res, 200, await match.handler({ req, user, token, body, params, query: Object.fromEntries(url.searchParams) }));
}

const ICONS = {
  bike: '<circle cx="25" cy="65" r="15"/><circle cx="75" cy="65" r="15"/><path d="M25 65L45 35H65L75 65M45 35L55 65H25M40 28H50M62 28H70"/>',
  ski: '<path d="M20 85L60 15M40 85L80 15M14 85h12M34 85h12"/>',
  board: '<g transform="rotate(30 50 50)"><rect x="38" y="6" width="24" height="88" rx="12"/><path d="M42 38h16M42 62h16"/></g>',
  roller: '<path d="M25 20H50V50H80V70H25Z"/><circle cx="35" cy="80" r="6"/><circle cx="70" cy="80" r="6"/>',
  tent: '<path d="M10 80L50 20L90 80ZM50 20V80M35 80L50 55L65 80"/>',
  bag: '<rect x="25" y="25" width="50" height="60" rx="12"/><path d="M38 25V15H62V25M35 55H65"/>',
  stove: '<rect x="30" y="60" width="40" height="15" rx="3"/><path d="M50 60V45M35 45H65M42 35Q50 15 58 35"/>',
  kayak: '<path d="M8 55Q50 35 92 55Q50 75 8 55ZM30 55H70M25 25L75 80"/>',
  drill: '<path d="M15 35H65V55H15ZM65 42H90M35 55V80H50V55"/>',
  saw: '<path d="M10 35H90V55H10ZM10 55l5 8 5-8 5 8 5-8 5 8 5-8 5 8 5-8 5 8 5-8 5 8 5-8 5 8"/>',
  ladder: '<path d="M32 10L25 90M68 10L75 90M30 30H70M28 50H72M26 70H74"/>',
  mixer: '<path d="M30 25H70L80 60H20ZM50 60V75M30 85H70M40 75H60"/>',
  default: '<path d="M20 35L50 20L80 35V70L50 85L20 70ZM20 35L50 50L80 35M50 50V85"/>',
};
function placeholder(res, key) {
  const hue = [...key].reduce((a, c) => a + c.charCodeAt(0), 0) * 37 % 360;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 260"><rect width="400" height="260" fill="hsl(${hue},28%,93%)"/>
<g transform="translate(140 70) scale(1.2)" fill="none" stroke="hsl(${hue},35%,38%)" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">${ICONS[key] || ICONS.default}</g></svg>`;
  res.writeHead(200, { 'Content-Type': MIME['.svg'], 'Cache-Control': 'no-cache' });
  res.end(svg);
}
function serveStatic(res, pathname) {
  let file = path.normalize(path.join(PUB, pathname === '/' ? 'index.html' : pathname));
  if (!file.startsWith(PUB) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(PUB, 'index.html');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (url.pathname.startsWith('/img/')) return placeholder(res, url.pathname.slice(5));
    serveStatic(res, url.pathname);
  } catch (e) {
    let status = e.status || 500, msg = e.message;
    if (!e.status) {
      if (/UNIQUE/.test(msg)) { status = 409; msg = 'Такая запись уже существует'; }
      else if (/FOREIGN KEY/.test(msg)) { status = 409; msg = 'Есть связанные записи — действие невозможно'; }
      else if (/CHECK|constraint/i.test(msg)) { status = 400; msg = 'Данные нарушают ограничения (проверьте значения)'; }
      else { msg = 'Внутренняя ошибка сервера'; console.error(e); }
    }
    send(res, status, { error: msg });
  }
});

if (require.main === module) {
  const port = process.env.PORT || 3000;
  server.listen(port, () => console.log(`Прокат оборудования: http://localhost:${port}`));
}
module.exports = { server };
