// Работа с БД: SQLite через встроенный модуль node:sqlite (Node.js >= 22.5, без npm-зависимостей)
const { DatabaseSync } = require('node:sqlite');
const crypto = require('crypto');
const path = require('path');

const db = new DatabaseSync(process.env.DB_FILE || path.join(__dirname, 'rental.db'));
db.exec('PRAGMA foreign_keys = ON;');
if (!process.env.DB_FILE) db.exec('PRAGMA journal_mode = WAL;');

// ---------- утилиты дат (даты хранятся строкой YYYY-MM-DD) ----------
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const addDays = (s, n) => {
  const d = new Date(s + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
const diffDays = (a, b) => Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 864e5);

// ---------- пароли ----------
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.scryptSync(pw, salt, 64).toString('hex');
}
function verifyPassword(pw, stored) {
  const [salt, hash] = stored.split(':');
  const h = crypto.scryptSync(pw, salt, 64);
  return crypto.timingSafeEqual(h, Buffer.from(hash, 'hex'));
}

// ---------- схема ----------
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL CHECK(length(name) >= 2),
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'client' CHECK(role IN ('client','manager','admin')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS categories(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE CHECK(length(name) >= 2)
);
CREATE TABLE IF NOT EXISTS equipment(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL REFERENCES categories(id),
  name TEXT NOT NULL CHECK(length(name) >= 2),
  description TEXT NOT NULL DEFAULT '',
  photo TEXT NOT NULL DEFAULT '',
  price_per_day REAL NOT NULL CHECK(price_per_day > 0),
  qty_total INTEGER NOT NULL DEFAULT 0 CHECK(qty_total >= 0),
  qty_repair INTEGER NOT NULL DEFAULT 0 CHECK(qty_repair >= 0),
  qty_written_off INTEGER NOT NULL DEFAULT 0 CHECK(qty_written_off >= 0),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  CHECK(qty_repair + qty_written_off <= qty_total)
);
CREATE TABLE IF NOT EXISTS bookings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  equipment_id INTEGER NOT NULL REFERENCES equipment(id),
  qty INTEGER NOT NULL CHECK(qty > 0),
  date_from TEXT NOT NULL,
  date_to TEXT NOT NULL,
  total_price REAL NOT NULL CHECK(total_price >= 0),
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK(status IN ('pending','confirmed','issued','returned','overdue','cancelled')),
  condition_out TEXT NOT NULL DEFAULT '',
  condition_in TEXT NOT NULL DEFAULT '',
  fine REAL NOT NULL DEFAULT 0 CHECK(fine >= 0),
  fine_reason TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  issued_at TEXT,
  returned_at TEXT,
  CHECK(date_to >= date_from)
);
CREATE INDEX IF NOT EXISTS idx_bookings_eq_dates ON bookings(equipment_id, date_from, date_to);
CREATE INDEX IF NOT EXISTS idx_bookings_user ON bookings(user_id);
CREATE TABLE IF NOT EXISTS tariffs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  min_days INTEGER NOT NULL UNIQUE CHECK(min_days >= 2),
  discount_percent REAL NOT NULL CHECK(discount_percent > 0 AND discount_percent <= 90)
);
CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS stock_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  equipment_id INTEGER NOT NULL REFERENCES equipment(id),
  user_id INTEGER REFERENCES users(id),
  action TEXT NOT NULL CHECK(action IN ('add','repair','restore','writeoff')),
  qty INTEGER NOT NULL CHECK(qty > 0),
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// ---------- начальные данные ----------
function seed() {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) return;
  const addUser = db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)');
  addUser.run('Администратор', 'admin@rental.local', hashPassword('admin123'), 'admin');
  addUser.run('Менеджер Анна', 'manager@rental.local', hashPassword('manager123'), 'manager');
  const clients = [
    ['Иван Петров', 'client@rental.local'],
    ['Мария Смирнова', 'maria@rental.local'],
    ['Пётр Орлов', 'petr@rental.local'],
  ].map(([n, e]) => Number(addUser.run(n, e, hashPassword('client123'), 'client').lastInsertRowid));

  db.prepare("INSERT INTO settings(key,value) VALUES('overdue_coef','1.5')").run();
  const addTariff = db.prepare('INSERT INTO tariffs(name,min_days,discount_percent) VALUES(?,?,?)');
  addTariff.run('От 3 суток', 3, 5);
  addTariff.run('Неделя', 7, 10);
  addTariff.run('Две недели', 14, 15);

  const cats = {};
  for (const n of ['Спортивное', 'Туристическое', 'Строительное'])
    cats[n] = Number(db.prepare('INSERT INTO categories(name) VALUES(?)').run(n).lastInsertRowid);

  const items = [
    ['Спортивное', 'Горный велосипед', 'Алюминиевая рама, 21 скорость, дисковые тормоза.', 'bike', 500, 6],
    ['Спортивное', 'Горные лыжи (комплект)', 'Лыжи, ботинки и палки, подбор по росту.', 'ski', 700, 8],
    ['Спортивное', 'Сноуборд', 'Универсальный сноуборд с креплениями.', 'board', 600, 5],
    ['Спортивное', 'Роликовые коньки', 'Раздвижные, размеры 34–46, комплект защиты.', 'roller', 300, 6],
    ['Туристическое', 'Палатка 3-местная', 'Двухслойная, водостойкость 3000 мм.', 'tent', 450, 7],
    ['Туристическое', 'Рюкзак 70 л', 'Анатомическая спинка, дождевик в комплекте.', 'bag', 200, 10],
    ['Туристическое', 'Газовая горелка', 'Компактная, с пьезоподжигом.', 'stove', 150, 9],
    ['Туристическое', 'Байдарка двухместная', 'Складная, весла и спасжилеты в комплекте.', 'kayak', 1200, 3],
    ['Строительное', 'Перфоратор', 'SDS-plus, 900 Вт, набор буров.', 'drill', 800, 5],
    ['Строительное', 'Электропила', 'Цепная, шина 40 см.', 'saw', 650, 4],
    ['Строительное', 'Стремянка 4 м', 'Алюминиевая, трёхсекционная.', 'ladder', 250, 6],
    ['Строительное', 'Бетономешалка', 'Объём 160 л, 650 Вт.', 'mixer', 1500, 2],
  ];
  const addEq = db.prepare('INSERT INTO equipment(category_id,name,description,photo,price_per_day,qty_total) VALUES(?,?,?,?,?,?)');
  const eqs = items.map(([c, n, d, p, pr, q]) => ({
    id: Number(addEq.run(cats[c], n, d, '/img/' + p, pr, q).lastInsertRowid), price: pr,
  }));
  db.prepare('UPDATE equipment SET qty_repair=1 WHERE name=?').run('Сноуборд');

  // демо-история для страницы статистики
  let s = 7;
  const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
  const addB = db.prepare(`INSERT INTO bookings(user_id,equipment_id,qty,date_from,date_to,total_price,status,
    condition_out,condition_in,fine,fine_reason,issued_at,returned_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  for (let i = 0; i < 40; i++) {
    const eq = eqs[Math.floor(rnd() * eqs.length)];
    const len = 1 + Math.floor(rnd() * 6), qty = 1 + Math.floor(rnd() * 2);
    const from = addDays(today(), -(len + 5 + Math.floor(rnd() * 150))), to = addDays(from, len - 1);
    const late = rnd() < 0.15 ? 1 + Math.floor(rnd() * 3) : 0;
    const fine = late * eq.price * qty * 1.5;
    addB.run(clients[i % 3], eq.id, qty, from, to, eq.price * qty * len, 'returned', 'Исправно', 'Исправно',
      fine, late ? `Просрочка ${late} дн.` : '', from, addDays(to, late));
  }
  const cur = (u, e, q, f, t, st) => {
    const eq = eqs[e], days = diffDays(f, t) + 1;
    addB.run(clients[u], eq.id, q, f, t, eq.price * q * days, st, st === 'issued' ? 'Исправно' : '', '', 0, '', st === 'issued' ? f : null, null);
  };
  cur(0, 4, 1, addDays(today(), 3), addDays(today(), 5), 'pending');
  cur(1, 0, 2, addDays(today(), 1), addDays(today(), 4), 'confirmed');
  cur(2, 8, 1, addDays(today(), -1), addDays(today(), 2), 'issued');
  cur(0, 7, 1, addDays(today(), -5), addDays(today(), -2), 'issued'); // станет «просрочено»
}
seed();
db.exec("UPDATE equipment SET photo = replace(photo, '/ph/', '/img/') WHERE photo LIKE '/ph/%'");

module.exports = { db, today, addDays, diffDays, hashPassword, verifyPassword };
