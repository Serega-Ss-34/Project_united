// Функциональные тесты API: валидация, граничные значения, пересечение дат, роли, штрафы
process.env.DB_FILE = ':memory:';
const test = require('node:test');
const assert = require('node:assert');
const { server } = require('../server');
const { today, addDays } = require('../db');

let base;
test.before(async () => { await new Promise((r) => server.listen(0, r)); base = 'http://localhost:' + server.address().port; });
test.after(() => server.close());

async function api(method, url, body, token) {
  const r = await fetch(base + url, {
    method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: r.status, data: await r.json() };
}
const login = async (email, password) => (await api('POST', '/api/login', { email, password })).data.token;

test('регистрация: валидация полей', async () => {
  assert.strictEqual((await api('POST', '/api/register', { name: 'A', email: 'a@b.ru', password: '123456' })).status, 400);
  assert.strictEqual((await api('POST', '/api/register', { name: 'Test', email: 'bad', password: '123456' })).status, 400);
  assert.strictEqual((await api('POST', '/api/register', { name: 'Test', email: 't@t.ru', password: '123' })).status, 400);
  assert.strictEqual((await api('POST', '/api/register', { name: 'Test', email: 't@t.ru', password: '123456' })).status, 200);
  assert.strictEqual((await api('POST', '/api/register', { name: 'Test', email: 't@t.ru', password: '123456' })).status, 409);
});

test('разграничение ролей', async () => {
  const client = await login('client@rental.local', 'client123');
  assert.strictEqual((await api('GET', '/api/me')).status, 401);
  assert.strictEqual((await api('GET', '/api/manager/bookings', null, client)).status, 403);
  assert.strictEqual((await api('GET', '/api/admin/stats', null, client)).status, 403);
});

test('бронирование: граничные значения и пересечение дат', async () => {
  const token = await login('client@rental.local', 'client123');
  const from = addDays(today(), 20), to = addDays(from, 1);
  // Палатка (id 5): 7 шт. Бронируем 7 — успех, ещё 1 на те же даты — отказ
  const mk = (qty, f = from, t = to) => api('POST', '/api/bookings', { equipment_id: 5, qty, date_from: f, date_to: t }, token);
  assert.strictEqual((await mk(0)).status, 400);
  assert.strictEqual((await mk(1, addDays(today(), -1), today())).status, 400, 'прошедшая дата');
  assert.strictEqual((await mk(1, to, from)).status, 400, 'конец раньше начала');
  assert.strictEqual((await mk(1, from, addDays(from, 60))).status, 400, 'более 60 суток');
  assert.strictEqual((await mk(8)).status, 409, 'больше, чем есть на складе');
  assert.strictEqual((await mk(7)).status, 200);
  assert.strictEqual((await mk(1)).status, 409, 'пересечение дат');
  assert.strictEqual((await mk(1, addDays(to, 1), addDays(to, 2))).status, 200, 'соседние даты не пересекаются');
  assert.strictEqual((await mk(1, from, from)).status, 409, 'пересечение в один день');
});

test('цена: скидка по тарифу', async () => {
  const f = addDays(today(), 40);
  const q1 = (await api('GET', `/api/quote?equipment_id=1&qty=2&from=${f}&to=${f}`)).data;
  assert.strictEqual(q1.total, 1000); // 500*2*1
  const q7 = (await api('GET', `/api/quote?equipment_id=1&qty=1&from=${f}&to=${addDays(f, 6)}`)).data;
  assert.strictEqual(q7.discount, 10);
  assert.strictEqual(q7.total, 3150); // 500*7*0.9
});

test('жизненный цикл: подтверждение, выдача, возврат с просрочкой и повреждением', async () => {
  const manager = await login('manager@rental.local', 'manager123');
  const list = (await api('GET', '/api/manager/bookings?status=overdue', null, manager)).data;
  assert.ok(list.length >= 1, 'есть просроченная аренда');
  const b = list[0];
  const r = await api('POST', `/api/bookings/${b.id}/return`, { condition_in: 'Царапины', damage_fine: 300, to_repair: 1 }, manager);
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.status, 'returned');
  // просрочено 2 суток: 2 * 1200 * 1 * 1.5 = 3600 + 300 повреждение
  assert.strictEqual(r.data.fine, 3900);
  assert.strictEqual((await api('POST', `/api/bookings/${b.id}/return`, {}, manager)).status, 400, 'повторный возврат');
});

test('склад: списание и ограничения', async () => {
  const admin = await login('admin@rental.local', 'admin123');
  assert.strictEqual((await api('POST', '/api/admin/stock', { equipment_id: 12, action: 'writeoff', qty: 3 }, admin)).status, 400);
  const r = await api('POST', '/api/admin/stock', { equipment_id: 12, action: 'writeoff', qty: 1 }, admin);
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.qty_written_off, 1);
  assert.strictEqual(r.data.working, 1);
});
